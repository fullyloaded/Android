package tw.org.iii.clickeventdemo;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class ActMain extends Activity  {


    View.OnClickListener btnOk_click=new View.OnClickListener(){
        public void onClick(View v) {

            double a = Double.parseDouble(txtA.getText().toString());
            double b = Double.parseDouble(txtB.getText().toString());
            double c = Double.parseDouble(txtC.getText().toString());
            double r=b*b-4*a*c;
            r=Math.sqrt(r);

            DecimalFormat format=new DecimalFormat("0.00");

            lblResult.setText("X="+format.format((-b+r)/(2*a))+
                    "或 X="+format.format((-b-r)/(2*a)));

    }};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);
        InitialComponent();
    }

    private void InitialComponent() {
        btnOk=(Button)findViewById(R.id.btnOk);
        btnOk.setOnClickListener(btnOk_click);
         txtA=(EditText)findViewById(R.id.txtA);
         txtB=(EditText)findViewById(R.id.txtB);
         txtC=(EditText)findViewById(R.id.txtC);
        lblResult=(TextView)findViewById(R.id.lblResult);

    }
    Button btnOk;
    EditText txtA;
    EditText txtB;
    EditText txtC;
    TextView lblResult;


}











