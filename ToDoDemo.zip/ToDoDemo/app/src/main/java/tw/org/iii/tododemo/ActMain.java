package tw.org.iii.tododemo;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class ActMain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);
        InitialComponent();
    }

    View.OnClickListener btnList_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            SharedPreferences table = getSharedPreferences("T1",0);
            int count=table.getInt("COUNT",0);
            if(count==0){
                Toast.makeText(ActMain.this, "沒有任何工作", Toast.LENGTH_SHORT).show();
                return;
            }
            ArrayList<String> list = new ArrayList<String>();
            for(int i =1;i<=count;i++){
                String keyT="T"+String.valueOf(i);
                if(table.contains(keyT)){
                    String keyD="D"+String.valueOf(i);
                    list.add(table.getString(keyT,"")+"\r\n"+
                            table.getString(keyD,""));
                }
            }
            if(list.size()==0){
                Toast.makeText(ActMain.this, "沒有任何工作", Toast.LENGTH_SHORT).show();
                return;
            }
            String[] datas=list.toArray(new String[list.size()]);
            AlertDialog.Builder build = new AlertDialog.Builder(ActMain.this);
            build.setTitle("未完成工作列表")
                    .setItems(datas, null)
                    .create()
                    .show();



      }
    };
    View.OnClickListener btnSave_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            SharedPreferences table = getSharedPreferences("T1",0);
            int count=table.getInt("COUNT",0);
            count++;
            table.edit().putInt("COUNT",count).commit();

            String keyT="T"+String.valueOf(count);
            String keyD="D"+String.valueOf(count);

            table.edit().putString(keyT,txtTodo.getText().toString()).commit();
            table.edit().putString(keyD,txtDate.getText().toString()).commit();
            Toast.makeText(ActMain.this, "新增資料成功", Toast.LENGTH_SHORT).show();

            txtDate.setText("");
            txtTodo.setText("");

        }
    };

    private void InitialComponent() {
        txtDate=(EditText)findViewById(R.id.txtDate);
        txtTodo=(EditText)findViewById(R.id.txtTodo);
        btnList=(Button)findViewById(R.id.btnList);
        btnList.setOnClickListener(btnList_click);
        btnSave=(Button)findViewById(R.id.btnSave);
        btnSave.setOnClickListener(btnSave_click);

    }
    EditText txtTodo;
    EditText txtDate;
    Button btnSave;
    Button btnList;
}
