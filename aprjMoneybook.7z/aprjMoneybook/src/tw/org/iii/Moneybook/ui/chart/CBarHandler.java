package tw.org.iii.Moneybook.ui.chart;

import java.text.DecimalFormat;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

public class CBarHandler {
	private Canvas iv_canvas;
	private int iv_intCanvasColor=0;
	private int iv_intFrontColor=0;
	private int iv_intMargin=0;
	private int iv_intIntervalLength=0;
	private int iv_intChartBackgroundColor1=0;
	private int iv_intChartBackgroundColor2=0;
	private int iv_intLineColor=0;
	private int iv_intChartBarColor=0;
	private boolean iv_blnIsShowLine;
		
	
	
	public Canvas Draw(Canvas p_canvas,CChartItem[] p_items){
		iv_canvas=p_canvas;
		p_canvas.drawColor(iv_intCanvasColor);
		Paint l_paint=new Paint(5);
		l_paint.setColor(iv_intFrontColor);
		l_paint.setAntiAlias(true);
		int l_intChartWidth=p_canvas.getWidth()-iv_intMargin*2;
		int l_intChartHeight=p_canvas.getHeight()*4/5;
		int l_intIntervalY=l_intChartHeight/10;
		int l_intIntervalX=l_intChartWidth/(p_items.length+1);
		int l_intBarWidth=l_intIntervalX/2;
//		p_canvas.drawLine(iv_intMargin, iv_intMargin+l_intChartWidth, iv_intMargin+l_intChartWidth, iv_intMargin+l_intChartWidth,l_paint);
//		p_canvas.drawLine(iv_intMargin, iv_intMargin, iv_intMargin, iv_intMargin+l_intChartWidth,l_paint);
		l_paint.setColor(iv_intChartBackgroundColor1);
		p_canvas.drawRoundRect(new RectF(iv_intMargin, iv_intMargin, iv_intMargin+l_intChartWidth, iv_intMargin+l_intChartHeight), 10, 10, l_paint);
		//p_canvas.drawRect(iv_intMargin, iv_intMargin, iv_intMargin+l_intChartWidth, iv_intMargin+l_intChartHeight,l_paint);
		
		for(int i=1;i<10;i++){// Y�b����
			l_paint.setColor(iv_intChartBackgroundColor2);
			p_canvas.drawLine(iv_intMargin, l_intIntervalY*i+iv_intMargin, iv_intMargin+l_intChartWidth, l_intIntervalY*i+iv_intMargin,l_paint);
			//p_canvas.drawRect(new RectF(iv_intMargin, l_intIntervalY*i+iv_intMargin, iv_intMargin+l_intChartWidth, l_intIntervalY*(i+1)+iv_intMargin),l_paint);
			//p_canvas.drawRect(iv_intMargin, l_intIntervalY*i+iv_intMargin, iv_intMargin+l_intChartWidth, l_intIntervalY*i+iv_intMargin, l_paint);
			
		}
			//p_canvas.drawLine(iv_intMargin-iv_intIntervalLength/2, l_intIntervalY*i+iv_intMargin, iv_intMargin+iv_intIntervalLength/2, l_intIntervalY*i+iv_intMargin,l_paint);
		double l_dblSum=0;
		for(int i=1;i<=p_items.length;i++){// X�b����P��u
			l_dblSum+=p_items[i-1].GetData();
			l_paint.setColor(iv_intFrontColor);
			p_canvas.drawLine(iv_intMargin+l_intIntervalX*i, iv_intMargin+l_intChartHeight-iv_intIntervalLength/2, iv_intMargin+l_intIntervalX*i,iv_intMargin+ l_intChartHeight+iv_intIntervalLength/2,l_paint);
			
			l_paint.setTextSize(25);
			p_canvas.drawText(String.valueOf(i),iv_intMargin+l_intIntervalX*i,  iv_intMargin+l_intChartHeight+iv_intIntervalLength*2, l_paint);
		}
		double l_dblMax=0;
		for(int i=0;i<p_items.length;i++){
			if(p_items[i].GetData()>l_dblMax)
				l_dblMax=p_items[i].GetData();
			
		}
		float l_fltUnit= (float)( l_dblMax/10);
		
		for(int i=1;i<=p_items.length;i++){// ���
			l_paint.setColor(iv_intChartBarColor);			
			float l_intY=(float)(((l_dblMax-p_items[i-1].GetData())/l_fltUnit)*l_intIntervalY+iv_intMargin);			
			p_canvas.drawRect(iv_intMargin+l_intIntervalX*i-l_intBarWidth/2, l_intY, iv_intMargin+l_intIntervalX*i+l_intBarWidth/2,iv_intMargin+ l_intChartHeight-1,l_paint);

			l_paint.setColor(iv_intLineColor);
			p_canvas.drawRoundRect(new RectF(iv_intMargin+l_intIntervalX*i-iv_intIntervalLength/2, l_intY-iv_intIntervalLength/2,
					iv_intMargin+l_intIntervalX*i+iv_intIntervalLength/2, l_intY+iv_intIntervalLength/2),2, 2, l_paint);
			
			DecimalFormat l_format=new DecimalFormat("0"); 
			l_paint.setColor(iv_intFrontColor);
			l_paint.setTextSize(16);
			p_canvas.drawText(p_items[i-1].GetTitle()+"("+
					l_format.format((p_items[i-1].GetData()*100)/l_dblSum)+
					"%)" ,iv_intMargin+l_intIntervalX*i-l_intBarWidth, l_intY-iv_intIntervalLength, l_paint);
			
		}
		for(int i=1;i<=p_items.length;i++){// ���
			float l_intY=(float)(((l_dblMax-p_items[i-1].GetData())/l_fltUnit)*l_intIntervalY+iv_intMargin);			
			DecimalFormat l_format=new DecimalFormat("0"); 
			l_paint.setColor(iv_intFrontColor);
			l_paint.setTextSize(16);
			p_canvas.drawText(p_items[i-1].GetTitle()+"("+
					l_format.format((p_items[i-1].GetData()*100)/l_dblSum)+
					"%)" ,iv_intMargin+l_intIntervalX*i-l_intBarWidth, l_intY-iv_intIntervalLength, l_paint);
			
		}		
		if(iv_blnIsShowLine){
			for(int i=1;i<=p_items.length;i++){// ���
				
				float l_intY=(float)(((l_dblMax-p_items[i-1].GetData())/l_fltUnit)*l_intIntervalY+iv_intMargin);						
				l_paint.setColor(iv_intLineColor);
				l_paint.setStrokeWidth(5);
				p_canvas.drawRoundRect(new RectF(iv_intMargin+l_intIntervalX*i-iv_intIntervalLength/2, l_intY-iv_intIntervalLength/2,
						iv_intMargin+l_intIntervalX*i+iv_intIntervalLength/2, l_intY+iv_intIntervalLength/2),2, 2, l_paint);
				if(i<p_items.length){
					float l_intY2=(float)(((l_dblMax-p_items[i].GetData())/l_fltUnit)*l_intIntervalY+iv_intMargin);
					p_canvas.drawLine(iv_intMargin+l_intIntervalX*i, l_intY,
						iv_intMargin+l_intIntervalX*(i+1), l_intY2, l_paint);
				}
			}
		}
	
		return p_canvas;
	}

	public void SetCanvasColor(int iv_intCanvasColor) {
		this.iv_intCanvasColor = iv_intCanvasColor;
	}

	public int GetCanvasColor() {
		return iv_intCanvasColor;
	}

	public void SetFrontColor(int iv_intFrontCanvasColor) {
		this.iv_intFrontColor = iv_intFrontCanvasColor;
	}

	public int GetFrontColor() {
		return iv_intFrontColor;
	}

	public void SetMargin(int iv_intMargin) {
		this.iv_intMargin = iv_intMargin;
	}

	public int GetMargin() {
		return iv_intMargin;
	}

	public void SetIntervalLength(int iv_intIntervalLength) {
		this.iv_intIntervalLength = iv_intIntervalLength;
	}

	public int GetIntervalLength() {
		return iv_intIntervalLength;
	}

	public void SetChartBackgroundColor1(int iv_intChartBackgroundColor1) {
		this.iv_intChartBackgroundColor1 = iv_intChartBackgroundColor1;
	}

	public int GetChartBackgroundColor1() {
		return iv_intChartBackgroundColor1;
	}

	public void SetChartBackgroundColor2(int iv_intChartBackgroundColor2) {
		this.iv_intChartBackgroundColor2 = iv_intChartBackgroundColor2;
	}

	public int GetChartBackgroundColor2() {
		return iv_intChartBackgroundColor2;
	}

	public void SetLineColor(int iv_intLineColor) {
		this.iv_intLineColor = iv_intLineColor;
	}

	public int GetLineColor() {
		return iv_intLineColor;
	}

	public void SetIsShowLine(boolean iv_blnIsShowLine) {
		this.iv_blnIsShowLine = iv_blnIsShowLine;
	}

	public boolean GetIsShowLine() {
		return iv_blnIsShowLine;
	}

	public void SetChartBarColor(int iv_intChartBarColor) {
		this.iv_intChartBarColor = iv_intChartBarColor;
	}

	public int GetChartBarColor() {
		return iv_intChartBarColor;
	}

}
