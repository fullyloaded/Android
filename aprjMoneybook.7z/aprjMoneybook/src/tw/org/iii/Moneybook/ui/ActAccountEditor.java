package tw.org.iii.Moneybook.ui;

import java.text.DecimalFormat;
import java.util.Calendar;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CAccount;
import tw.org.iii.Moneybook.lib.da.CAccountFactory;
import tw.org.iii.Moneybook.lib.da.CCode;
import tw.org.iii.Moneybook.lib.da.CItem;
import tw.org.iii.Moneybook.lib.util.CDateUtility;
import tw.org.iii.Moneybook.ui.common.ActCalculatorInput;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActAccountEditor extends Activity {
	
	private CAccount iv_item;
	private String iv_intFocusField="";
	private String[] iv_strTypes=null;
	private boolean IsUiValidated() {		
		String l_str="";
		if("".equals(txtName.getText().toString()))
			l_str+="\r\n��������J�W��";
//		if("".equals(txtDate.getText().toString()))
//			l_str+="\r\n��������J���";
//		if(txtDate.getText().toString().length()!=10)
//			l_str+="\r\n����J������榡���~�A�����OYYYY-MM-DD";
		if(!"".equals(l_str))
			CDictionary.CCONTEXT.ShowMessage(this,l_str,"�������");
			
			return "".equals(l_str);
	}
	private CAccount GetFilled(CAccount p_item){
		
		p_item.SetMoney(Double.parseDouble(btnMoney.getText().toString()));		
		p_item.SetName(txtName.getText().toString());
		try{
			p_item.SetRate(Double.parseDouble(btnRate.getText().toString()));
		}catch(Exception ex){
			p_item.SetRate(1);
		}
		p_item.SetBank(txtBank.getText().toString());
		p_item.SetPassword(txtPassword.getText().toString());
		p_item.SetAccount(txtAccount.getText().toString());
		p_item.SetType(btnType.getText().toString());
		p_item.SetAccount(txtMemo.getText().toString());
		return p_item;
	}	
	private CAccount GetItem(){
		if (iv_item==null)
			iv_item=CDictionary.CCONTEXT.GetAccountFactory().Create();
		return iv_item;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.accounteditor);
		InicialComponent();
		iv_strTypes=(String[])getResources().getStringArray(R.array.account_type);
		btnType.setText(iv_strTypes[0]);
		btnMoney.setText("0");
		
		if(getIntent().getExtras()!=null){
        	int l_int=getIntent().getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);        	
        	iv_item=CDictionary.CCONTEXT.GetAccountFactory().GetById(l_int);        	
        	if(iv_item!=null){        	
        		DisplayAccount(iv_item);
        	}
        }
	}
	
    private void DisplayAccount(CAccount iv_item2) {
		txtName.setText(iv_item2.GetName());
		//DecimalFormat l_format=new DecimalFormat("0");
		btnMoney.setText(String.valueOf( iv_item2.GetMoney()));
		btnRate.setText(String.valueOf( iv_item2.GetRate()));
		txtPassword.setText(iv_item2.GetPassword());
		txtBank.setText(iv_item2.GetBank());
		txtAccount.setText(iv_item2.GetAccount());
		btnType.setText(iv_item2.GetType());
		txtMemo.setText(iv_item2.GetMemo());
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		try{
			if(requestCode==CDictionary.ACTIVEID_CALCULATORINPUT){
				double l_dbl=data.getExtras().getDouble(CDictionary.BUNDLE_KEY_MENU_TYPE);
				DecimalFormat l_format = new DecimalFormat("0.#");
				if(CAccountFactory.FIELD_MONEY.equals(iv_intFocusField))
					btnMoney.setText(l_format.format(l_dbl));
				else if(CAccountFactory.FIELD_RATE.equals(iv_intFocusField))
					btnRate.setText(l_format.format(l_dbl));
			}
		}catch(Exception ex){
			
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	OnClickListener btnClearMoney_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			btnMoney.setText("0");
		}
    }; 
    OnClickListener btnClearName_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			txtName.setText("");
		}
    }; 
    OnClickListener btnClearRate_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			btnRate.setText("1");
		}
    }; 
    OnClickListener btnClearPassword_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			txtPassword.setText("");
		}
    };     
    OnClickListener btnClearBank_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			txtBank.setText("");
		}
    }; 
        
    OnClickListener btnClearAccount_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			txtAccount.setText("");
		}
    }; 
    OnClickListener btnClearType_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			btnType.setText(iv_strTypes[0]);	
		}
    }; 
    OnClickListener btnClearMemo_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			txtMemo.setText("");
		}
    }; 
    OnClickListener btnMoney_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			iv_intFocusField=CAccountFactory.FIELD_MONEY;
			Intent l_intent=new Intent(ActAccountEditor.this,ActCalculatorInput.class);
			startActivityForResult(l_intent, CDictionary.ACTIVEID_CALCULATORINPUT);
		}
    }; 
    OnClickListener btnRate_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			iv_intFocusField=CAccountFactory.FIELD_RATE;
			Intent l_intent=new Intent(ActAccountEditor.this,ActCalculatorInput.class);
			startActivityForResult(l_intent, CDictionary.ACTIVEID_CALCULATORINPUT);
		}
    }; 
    OnClickListener btnType_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {			
			Builder l_build=new AlertDialog.Builder(ActAccountEditor.this);
			//l_build.setIcon(R.drawable.icon);
			l_build.setTitle(R.string.title_select_item);
			l_build.setItems(iv_strTypes,new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface dialog, int which) {
						btnType.setText(iv_strTypes[which]);					
				}});
					
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
		}
    }; 
    
    OnClickListener btnOk_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			if(IsUiValidated()){				
				CDictionary.CCONTEXT.GetAccountFactory().Update(GetFilled(GetItem()));
				finish();								
				Toast.makeText(ActAccountEditor.this,R.string.message_save_successfull,Toast.LENGTH_SHORT).show();
			}
		}


    }; 
    OnClickListener btnCancel_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			finish();		
		}
    };     
	private void InicialComponent() {
		btnClearName=(ImageButton)findViewById(R.id.AccountEditor_btnClearName);
		btnClearName.setOnClickListener(btnClearName_Click);
		btnClearMoney=(ImageButton)findViewById(R.id.AccountEditor_btnClearMoney);
		btnClearMoney.setOnClickListener(btnClearMoney_Click);
		btnClearRate=(ImageButton)findViewById(R.id.AccountEditor_btnClearRate);
		btnClearRate.setOnClickListener(btnClearRate_Click);
		btnClearPassword=(ImageButton)findViewById(R.id.AccountEditor_btnClearPassword);
		btnClearPassword.setOnClickListener(btnClearPassword_Click);
		btnClearBank=(ImageButton)findViewById(R.id.AccountEditor_btnClearBank);
		btnClearBank.setOnClickListener(btnClearBank_Click);
		btnClearAccount=(ImageButton)findViewById(R.id.AccountEditor_btnClearAccount);
		btnClearAccount.setOnClickListener(btnClearAccount_Click);	
		btnClearType=(ImageButton)findViewById(R.id.AccountEditor_btnClearType);
		btnClearType.setOnClickListener(btnClearType_Click);
		btnClearMemo=(ImageButton)findViewById(R.id.AccountEditor_btnClearMemo);
		btnClearMemo.setOnClickListener(btnClearMemo_Click);
		
		btnMoney=(Button)findViewById(R.id.AccountEditor_btnMoney);
		btnMoney.setOnClickListener(btnMoney_Click);
		btnRate=(Button)findViewById(R.id.AccountEditor_btnRate);
		btnRate.setOnClickListener(btnRate_Click);
		btnType=(Button)findViewById(R.id.AccountEditor_btnType);
		btnType.setOnClickListener(btnType_Click);
		btnOk=(Button)findViewById(R.id.AccountEditor_btnOk);
		btnOk.setOnClickListener(btnOk_Click);
		btnCancel=(Button)findViewById(R.id.AccountEditor_btnCancel);
		btnCancel.setOnClickListener(btnCancel_Click);
		
		txtName=(EditText)findViewById(R.id.AccountEditor_txtName);		
		txtPassword=(EditText)findViewById(R.id.AccountEditor_txtPassword);
		txtBank=(EditText)findViewById(R.id.AccountEditor_txtBank);
		txtAccount=(EditText)findViewById(R.id.AccountEditor_txtAccount);
		txtMemo=(EditText)findViewById(R.id.AccountEditor_txtMemo);
		
	}
	ImageButton btnClearName=null;
	ImageButton btnClearMoney=null;
	ImageButton btnClearRate=null;
	ImageButton btnClearPassword=null;
	ImageButton btnClearBank=null;
	ImageButton btnClearAccount=null;
	ImageButton btnClearType=null;
	ImageButton btnClearMemo=null;
	EditText txtName=null;
	EditText txtPassword=null;
	EditText txtBank=null;
	EditText txtAccount=null;
	EditText txtMemo=null;
	Button btnMoney=null;
	Button btnRate=null;
	Button btnType=null;
	Button btnOk=null;
	Button btnCancel=null;
	
	
	
}
