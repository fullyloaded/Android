package tw.org.iii.Moneybook.ui;

import java.util.ArrayList;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CCode;
import tw.org.iii.Moneybook.lib.da.CCodeQueryKey;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class ActCodeEditor extends Activity {
	public  static String EDITOR_TYPE="";	
	private int iv_intSelectedIndex=-1;
	private int iv_intCatalogId=-1;
	
	private ArrayList<CCode> iv_list=new ArrayList<CCode>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.codeditor);
		InicialComponent();
		String l_strTitle=(String)getResources().getString(R.string.home_basic_data);
		if(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT.equals(EDITOR_TYPE))
			l_strTitle+=">"+(String)getResources().getString(R.string.itemeditor_title_catalog_payment);
		else if(CDictionary.EDITOR_TYPE_CATALOG_INCOME.equals(EDITOR_TYPE))
			l_strTitle+=">"+(String)getResources().getString(R.string.itemeditor_title_catalog_income);
		else if(CDictionary.EDITOR_TYPE_PROJECT.equals(EDITOR_TYPE))
			l_strTitle+=">"+(String)getResources().getString(R.string.itemeditor_field_project);
		
		
		
		if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals(EDITOR_TYPE)||
				CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals(EDITOR_TYPE)){			
			
			if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals(EDITOR_TYPE))
				l_strTitle+=">"+(String)getResources().getString(R.string.itemeditor_title_catalog_payment);
			else if(CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals(EDITOR_TYPE))
				l_strTitle+=">"+(String)getResources().getString(R.string.itemeditor_title_catalog_income);			
			
			l_strTitle+=">"+(String)getResources().getString(R.string.itemeditor_title_catalogsub);
			if(getIntent().getExtras()!=null){
				iv_intCatalogId=getIntent().getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);
				String l_strCatalogValue=getIntent().getExtras().getString(CDictionary.BUNDLE_KEY_MENU_TYPE);
				
			}
		}
		lblTitil.setText(l_strTitle);
		RefreshData();
	}

	private void DisplayData() {
		String[] l_strCodes=new String[iv_list.size()];
		for(int i=0 ;i<iv_list.size();i++){
			l_strCodes[i]=((CCode)iv_list.get(i)).GetValue();
		}
    	ListAdapter l_adapter=new ArrayAdapter<String>(
    			this,android.R.layout.simple_list_item_single_choice, l_strCodes);
		lstMenu.setAdapter(l_adapter);   
	}    	
	
	private void  RefreshData(){
		CCode[] l_codes=null;		
		if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals(EDITOR_TYPE)){
			l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetPaymentCatalogSub(iv_intCatalogId);
			
		}else if(	CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals(EDITOR_TYPE)){		
			l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetIncomeCatalogSub(iv_intCatalogId);
			
		}else{
			l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByType(EDITOR_TYPE);
			
		}
		iv_list.clear();
		if(l_codes!=null){
			for(int i=0;i<l_codes.length;i++){
				if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals(EDITOR_TYPE)||
						CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals(EDITOR_TYPE)){
					Log.d(CDictionary.DEBUG_TAG,"�l����ID-"+String.valueOf(l_codes[i].GetKey()+" / "+l_codes[i].GetValue()));
					if(l_codes[i].GetKey().equals(String.valueOf(iv_intCatalogId)))
						iv_list.add(l_codes[i]);
				}else{
					iv_list.add(l_codes[i]);
				}
			}
			DisplayData();
		}
	}
	
    OnClickListener btnNew_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			if(!"".equals(txtName.getText().toString()))
			{
					CCode l_code=CDictionary.CCONTEXT.GetCodeFactory().Create();
					l_code.SetType(EDITOR_TYPE);
					l_code.SetKey(EDITOR_TYPE);
					l_code.SetValue(txtName.getText().toString());
					Log.d(CDictionary.DEBUG_TAG,"�إߦ�����EDITOR_TYPE:"+EDITOR_TYPE);
					//		��I / ���J����
					if(CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals( ActCodeEditor.EDITOR_TYPE) ||
							CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals( ActCodeEditor.EDITOR_TYPE)){
						l_code.SetKey(String.valueOf(iv_intCatalogId));
						Log.d(CDictionary.DEBUG_TAG,"�إߦ�����TYPE:"+l_code.GetType());
						Log.d(CDictionary.DEBUG_TAG,"�إߦ�����KEY:"+l_code.GetKey());
						Log.d(CDictionary.DEBUG_TAG,"�إߦ�����NAME:"+l_code.GetName());
						Log.d(CDictionary.DEBUG_TAG,"�إߦ�����VALUE:"+l_code.GetValue());								
					}					
					CDictionary.CCONTEXT.GetCodeFactory().Update(l_code);
					RefreshData();
					
					Bundle l_bundle = new Bundle();
					l_bundle.putString(CDictionary.BUNDLE_KEY_MENU_TYPE, txtName.getText().toString());
					Intent l_intent=new Intent();
					l_intent.putExtras(l_bundle);
					setResult(0,l_intent);
					txtName.setText("");
			}
		}
    };    
	private void EnterCodeSubMode(int p_intParentIndex) {
		if(CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals( ActCodeEditor.EDITOR_TYPE) ||
				CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals( ActCodeEditor.EDITOR_TYPE) ||
				CDictionary.EDITOR_TYPE_PROJECT.equals( ActCodeEditor.EDITOR_TYPE) 
				){
			return;
		}

		CCode l_code=(CCode)iv_list.get(p_intParentIndex);
		Log.d(CDictionary.DEBUG_TAG,"�I�諸�����ئW�١G"+l_code.GetValue()+"-"+String.valueOf(l_code.GetId()));
		Bundle l_bundle=new Bundle();
		l_bundle.putString(CDictionary.BUNDLE_KEY_MENU_TYPE, l_code.GetValue());
		l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, l_code.GetId());
		Intent l_intent=new Intent();		
		l_intent.putExtras(l_bundle);
		setResult(0,l_intent);
		finish();
	}    
    OnItemClickListener  lstMenu_ItemClickListener=new OnItemClickListener(){
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {					
			
			EnterCodeSubMode(arg2);
			
		}
    	
    };
    OnItemLongClickListener  lstMenu_LongClick=new OnItemLongClickListener(){
		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View arg1,int arg2, long arg3) {
			
			Builder l_build=new Builder(ActCodeEditor.this);			
			l_build.setTitle(R.string.title_select_item);
			ListView l_lstView=(ListView)arg0;
			iv_intSelectedIndex=arg2;
			String[] l_strItems=null;
			if(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT.equals( ActCodeEditor.EDITOR_TYPE) ||
					CDictionary.EDITOR_TYPE_CATALOG_INCOME.equals( ActCodeEditor.EDITOR_TYPE)){
				 l_strItems=(String[])getResources().getStringArray(R.array.menu_longclick_basicdata_sub);
			}else {
				l_strItems=(String[])getResources().getStringArray(R.array.menu_longclick_basicdata);
			}
			
			l_build.setItems(l_strItems, new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {
						//		��I / ���J����
						if(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT.equals( ActCodeEditor.EDITOR_TYPE) ||
								CDictionary.EDITOR_TYPE_CATALOG_INCOME.equals( ActCodeEditor.EDITOR_TYPE)){
							HandleCatalogLongClick(which);
						}else	//		�M��/������ 
						{
							HandleProjectLongClick(which);	
						}
						
						
					}

					private void HandleCatalogLongClick(int which) {
						if(which==0){
							EnterCodeSubMode(iv_intSelectedIndex);
						}else if(which==1){
							SetDefaultCode();
						}
						else if(which==2){
							CCode l_code=(CCode)iv_list.get(iv_intSelectedIndex);
							CDictionary.CCONTEXT.GetCodeFactory().Delete(l_code);
							CDictionary.CCONTEXT.GetCodeFactory().DeleteByKey(String.valueOf( l_code.GetId()));
							iv_list.remove(iv_intSelectedIndex);
							DisplayData();
						}else if(which==3){
							
						}
					}



					private void HandleProjectLongClick(int which) {
						if(which==0){
							SetDefaultCode();
						}else if(which==1){
							DeleteDefaultCode();
						}else if(which==2){
							CCode l_code=(CCode)iv_list.get(iv_intSelectedIndex);
							CDictionary.CCONTEXT.GetCodeFactory().Delete(l_code);
							iv_list.remove(iv_intSelectedIndex);
							DisplayData();	
						}else if(which==3){
							
						}
					}
					
					private void DeleteDefaultCode(){
						CCode l_code=(CCode)iv_list.get(iv_intSelectedIndex);
						CCodeQueryKey l_key=new CCodeQueryKey();
						l_key.AddTypeEqual(CDictionary.EDITOR_TYPE_DEFAULT);
						l_key.AddKeyEqual(l_code.GetKey());
						CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(l_key);
						if(l_codes!=null)
							CDictionary.CCONTEXT.GetCodeFactory().Delete(l_codes[0]);
						Toast.makeText(ActCodeEditor.this,R.string.message_save_successfull,Toast.LENGTH_SHORT).show();
					}
					private void SetDefaultCode() {
						CCode l_code=(CCode)iv_list.get(iv_intSelectedIndex);
						CCode[] l_defaults=CDictionary.CCONTEXT.GetCodeFactory().GetByKeyAndType(
								l_code.GetKey(),CDictionary.EDITOR_TYPE_DEFAULT);
						
						Log.d(CDictionary.DEBUG_TAG,"SetDefaultCode");
						if(l_defaults==null){
							Log.d(CDictionary.DEBUG_TAG,"�s�عw�]��");
							l_defaults=new CCode[1];
							l_defaults[0]=new CCode();		
							l_defaults[0].SetType(CDictionary.EDITOR_TYPE_DEFAULT);
							l_defaults[0].SetKey(l_code.GetKey());
						}
						l_defaults[0].SetName(String.valueOf(l_code.GetId()));
						l_defaults[0].SetValue(l_code.GetValue());
						CDictionary.CCONTEXT.GetCodeFactory().Update(l_defaults[0]);
						Toast.makeText(ActCodeEditor.this,R.string.message_save_successfull,Toast.LENGTH_SHORT).show();
					}				
				}				
			);
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
			return false;
		}}; 
	private void InicialComponent() {
		btnNew=(ImageButton)findViewById(R.id.CodeEditor_btnNew);
		btnNew.setOnClickListener(btnNew_Click);
		txtName=(EditText)findViewById(R.id.CodeEditor_txtName);		
		lstMenu=(ListView)findViewById(R.id.CodeEditor_lstMenu);
		txtName.clearFocus(); 
		lblTitil=(TextView)findViewById(R.id.CodeEditor_lblTitle);
		lstMenu.setOnItemLongClickListener(lstMenu_LongClick);
		lstMenu.setOnItemClickListener(lstMenu_ItemClickListener);
		lstMenu.setCacheColorHint(0);
	}
	ImageButton btnNew=null;
	EditText txtName=null;
	ListView lstMenu=null;
	TextView lblTitil=null;
}