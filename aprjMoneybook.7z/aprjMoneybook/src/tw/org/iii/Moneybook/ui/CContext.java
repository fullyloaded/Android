package tw.org.iii.Moneybook.ui;

import tw.org.iii.Moneybook.lib.da.CAccountFactory;
import tw.org.iii.Moneybook.lib.da.CCodeFactory;
import tw.org.iii.Moneybook.lib.da.CConfig;
import tw.org.iii.Moneybook.lib.da.CDbManager;
import tw.org.iii.Moneybook.lib.da.CItemFactory;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;

public class CContext {
	private Context iv_context;
	private CItemFactory iv_itemFactory;
	private CCodeFactory iv_codeFactory;
	private CAccountFactory iv_accountFactory;
	private CDbManager iv_dbManager;
	private CConfig iv_config;
	
	public void SetContext(Context p_context){
		iv_context=p_context;		
	}
	
	public CConfig GetConfig(){
		if(iv_config==null)
			iv_config=new CConfig(this);
		return iv_config;
	}
	
	public void ShowMessage(Context p_context,String p_strMessage,String p_strTitle){
		Builder l_build=new AlertDialog.Builder(p_context);		
		l_build.setTitle(p_strTitle);
		l_build.setMessage(p_strMessage);			
		l_build.setPositiveButton("�T�w", null);
		Dialog l_dialog=l_build.create();
		l_dialog.show();
	}
	
	public void StartManagingCursor(Cursor p_cursor){
		Activity l_activity=(Activity)iv_context;
		l_activity.startManagingCursor(p_cursor);
	}
	public CContext(Context p_context){
		iv_context=p_context;
	}
	
	public CCodeFactory GetCodeFactory(){
		if(iv_codeFactory==null){
			iv_codeFactory=new CCodeFactory(this);			
		}
		return iv_codeFactory;
	}
	public CAccountFactory GetAccountFactory(){
		if(iv_accountFactory==null){
			iv_accountFactory=new CAccountFactory(this);			
		}
		return iv_accountFactory;
	}
	public CItemFactory GetItemFactory(){
		if(iv_itemFactory==null){
			iv_itemFactory=new CItemFactory(this);			
		}
		return iv_itemFactory;
	}
	public CDbManager GetDbManager(){
		if(iv_dbManager==null)
			iv_dbManager=new CDbManager(iv_context);
		return iv_dbManager;
	}
	
	
	
	

}
