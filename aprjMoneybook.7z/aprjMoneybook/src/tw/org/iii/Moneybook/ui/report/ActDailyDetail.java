package tw.org.iii.Moneybook.ui.report;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CItem;
import tw.org.iii.Moneybook.lib.da.CItemFactory;
import tw.org.iii.Moneybook.lib.util.CDateUtility;
import tw.org.iii.Moneybook.ui.ActCodeEditor;
import tw.org.iii.Moneybook.ui.ActHome;
import tw.org.iii.Moneybook.ui.ActItemEditor;
import tw.org.iii.Moneybook.ui.CDictionary;
import tw.org.iii.Moneybook.ui.CHomeListAdapter;
import tw.org.iii.Moneybook.ui.CHomeTitle;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;

public class ActDailyDetail extends Activity {

	private int iv_intSelectedIndex=-1;
	private CItem[] iv_items;
	private int iv_intMode=-1;
	private String iv_strSql="";
	private String iv_strCindition="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reportstyle01);
		InicialComponent();
		
		if(getIntent().getExtras()!=null)
			iv_intMode=getIntent().getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);
		DisplayItemsDefault();		
	}

	private void DisplayItemsDefault() {
			if(CDictionary.REPORT_MODE_DAILY==iv_intMode){
				Calendar l_calendar=Calendar.getInstance();
				if(getIntent().getExtras().getString(CDictionary.BUNDLE_KEY_DATE)!=null){
					 l_calendar=CDateUtility.ToCalendarDate(getIntent().getExtras()
							.getString(CDictionary.BUNDLE_KEY_DATE).replace("-",""));
				}
				DisplayByDateRange( l_calendar, l_calendar);
			}
			else{
				DisplayByDateRange(CDateUtility.GetFirstDateOfMonth(Calendar.getInstance()),
						CDateUtility.GetLastDateOfMonth(Calendar.getInstance()));
			}				
	}
	
	private void DisplayByDateRange(Calendar p_calendarStart,Calendar p_calendarEnd){
		iv_items=CDictionary.CCONTEXT.GetItemFactory().GetItemByDateRange(
			CDateUtility.ToDateDbString(p_calendarStart)+"000000",
			CDateUtility.ToDateDbString(p_calendarEnd)+"999999"
		);
		lblCondition.setText(CDateUtility.GetFormatedDate(p_calendarStart)+" ~ "+
			CDateUtility.GetFormatedDate(p_calendarEnd));			
		
		if(iv_items==null)
			return;
		if(iv_intMode==CDictionary.REPORT_MODE_MONTH)
			iv_items=GroupByDate(iv_items);
		Log.d(CDictionary.DEBUG_TAG, "�s�դ�ơG"+String.valueOf(iv_items.length));
		DisplayItems(iv_items);    	
	}

	private CItem[] GroupByDate(CItem[] p_items) {
		if(p_items==null)
			return p_items;
		Hashtable l_set=new Hashtable();
		for(int i=0;i<p_items.length;i++){
			Log.d(CDictionary.DEBUG_TAG,String.valueOf(i));
			String l_str=p_items[i].GetDate().substring(0,8);
			CItem l_item=(CItem)l_set.get(l_str);
			if(l_item==null){
				l_item=new CItem();
				l_item.SetDate(p_items[i].GetDate());
				l_set.put(l_str, l_item);
			}
			l_item.SetMoney(l_item.GetMoney()+p_items[i].GetMoney());			
		}
		CItem[] l_items=new CItem[l_set.size()];
		Iterator l_iteartor=l_set.values().iterator();
		int l_intCount=0;
		while(l_iteartor.hasNext()){
			l_items[l_intCount]=(CItem)l_iteartor.next();
			Log.d(CDictionary.BUNDLE_KEY_MENU_TYPE, l_items[l_intCount].GetDate());
			l_intCount++;
		}
		SortByDate(l_items,CDictionary.SORT_BIGENDING);
		return l_items;
	}

	private void DisplayItems(CItem[] p_items) {
		if(p_items==null){
			lblResult.setText((String)getResources().getString(R.string.message_nodata));
    		List<CHomeTitle> l_list=new ArrayList<CHomeTitle>();				
    		CHomeListAdapter l_adapter=new  CHomeListAdapter(ActDailyDetail.this,0,l_list);		
    		lstDetail.setAdapter(l_adapter);
			return;
		}
		double l_dblPay=0,l_dblIn=0;
    	if(p_items!=null){
    		CHomeTitle[] l_todays=new CHomeTitle[p_items.length];    	
        	
    		for(int i=0;i<p_items.length;i++){
    			l_todays[i]=new CHomeTitle();
    			if(iv_intMode==CDictionary.REPORT_MODE_MONTH){

    				l_todays[i].SetTitle(CDateUtility.GetFormatedDate( p_items[i].GetDate()));
        			
    			}else{
    				l_todays[i].SetTitle(p_items[i].GetCatalog());
        			l_todays[i].SetSubTitle(CDateUtility.GetFormatedDate( p_items[i].GetDate())+" / "+
        					p_items[i].GetCatalogSub());
    			}
    			
    					
    			if(p_items[i].GetMoney()<0){
    				l_todays[i].SetPayment(p_items[i].GetMoney());    				
    				l_dblPay+=p_items[i].GetMoney();
				}	else{
					l_todays[i].SetIncome(p_items[i].GetMoney());
					l_dblIn+=p_items[i].GetMoney();
    			}
			}
    		
    		List<CHomeTitle> l_list=new ArrayList<CHomeTitle>();				
    		for(int i=0;i<l_todays.length;i++){
    			l_list.add(l_todays[i]);	
    		}
    		
    		CHomeListAdapter l_adapter=new  CHomeListAdapter(ActDailyDetail.this,0,l_list);		
    		lstDetail.setAdapter(l_adapter);
    		
    		DecimalFormat l_format=new DecimalFormat("0");
    		lblResult.setText(
    				(String)getResources().getString(R.string.item_income)+":"+
    				l_format.format(l_dblIn)+" ,"+
    				(String)getResources().getString(R.string.item_payment)+":"+
    				l_format.format(l_dblPay)+" ,"+
    				(String)getResources().getString(R.string.item_result)+":"+
    				l_format.format(l_dblIn+l_dblPay)
    				);
    	}
	}

	OnClickListener btnSearch_Click =new OnClickListener(){
		public void onClick(View arg0) {		
			
			Intent l_intent=new Intent(ActDailyDetail.this,ActQueryCondition.class);
			startActivityForResult(l_intent,CDictionary.ACTIVEID_QUERYCONDITION);
			
	}};	
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode==CDictionary.ACTIVEID_REPORT_DETAIL){
			iv_intMode=CDictionary.REPORT_MODE_MONTH;
			if(!"".equals(iv_strSql)){	// �p�G�O�d�߸�ƨíק�A�h�n���s����d��
				iv_items=CDictionary.CCONTEXT.GetItemFactory().GetBySql(iv_strSql);				
				iv_items=GroupByDate(iv_items);
				DisplayItems(iv_items);
				lblCondition.setText(iv_strCindition);
			}else{
				DisplayItemsDefault();
			}
			
		}
		if(requestCode==CDictionary.ACTIVEID_CODEEDITOR){
			DisplayItemsDefault();
		}
		if(requestCode==CDictionary.ACTIVEID_QUERYCONDITION){
			if(data==null)
				return;
			if(data.getExtras()!=null){
				iv_strSql=data.getExtras().getString(CDictionary.BUNDLE_KEY_MENU_TYPE);
				String l_str=data.getExtras().getString(CItemFactory.FIELD_DATE);
				iv_strCindition="";				
				if(l_str!=null)
					iv_strCindition+=l_str+"\r\n";
				l_str=data.getExtras().getString(CItemFactory.FIELD_ACCOUNT);		
				if(l_str!=null)
					iv_strCindition+=l_str+" ";				
				l_str=data.getExtras().getString(CItemFactory.FIELD_PROJECT);		
				if(l_str!=null)
					iv_strCindition+=l_str+" ";
				l_str=data.getExtras().getString(CItemFactory.FIELD_CATALOG);				
				if(l_str!=null)
					iv_strCindition+=l_str+" ";
				iv_items=CDictionary.CCONTEXT.GetItemFactory().GetBySql(iv_strSql);
				if(iv_intMode==CDictionary.REPORT_MODE_MONTH)
					iv_items=GroupByDate(iv_items);
				DisplayItems(iv_items);
				lblCondition.setText(iv_strCindition);
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void SortByDate(CItem[] p_items,int p_intSort){
		for(int i=0;i<p_items.length;i++){
			for(int j=0;j<p_items.length-1;j++){				
				if(p_intSort==CDictionary.SORT_LITLEENDING){
					if(p_items[j].GetDate().compareTo(p_items[j+1].GetDate())>0){
						CItem l_item=p_items[j];
						p_items[j]=p_items[j+1];
						p_items[j+1]=l_item;
					}
				}else{
					if(p_items[j].GetDate().compareTo(p_items[j+1].GetDate())<0){
						CItem l_item=p_items[j];
						p_items[j]=p_items[j+1];
						p_items[j+1]=l_item;
					}
				}
			}
		}	
	}
	
	OnItemLongClickListener   lstDetail_LongClick=new OnItemLongClickListener(){

		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
				int arg2, long arg3) {

			Builder l_build=new Builder(ActDailyDetail.this);			
			l_build.setTitle(R.string.title_select_item);
			ListView l_lstView=(ListView)arg0;
			iv_intSelectedIndex=arg2;
			String[] l_strItems=(String[])getResources().getStringArray(R.array.menu_longclick_basicdata_edit_delete);
			if(iv_intMode==CDictionary.REPORT_MODE_MONTH)
				l_strItems=(String[])getResources().getStringArray(R.array.menu_longclick_view_details);
			l_build.setItems(l_strItems, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					CItem l_item=iv_items[iv_intSelectedIndex];
					if(arg1==0){
						
						Bundle l_bundle=new Bundle();
						if(iv_intMode==CDictionary.REPORT_MODE_MONTH){
							
							l_bundle.putString(CDictionary.BUNDLE_KEY_DATE, l_item.GetDate());							
							l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_DAILY);
							Intent l_intent=new Intent(ActDailyDetail.this,ActDailyDetail.class);	
							l_intent.putExtras(l_bundle);
							startActivityForResult(l_intent,CDictionary.ACTIVEID_REPORT_DETAIL);
						}else{
							l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, l_item.GetId());
							Intent l_intent=new Intent(ActDailyDetail.this,ActItemEditor.class);	
							l_intent.putExtras(l_bundle);
							startActivityForResult(l_intent,CDictionary.ACTIVEID_CODEEDITOR);
						}
					}else if(arg1==1){
						CDictionary.CCONTEXT.GetItemFactory().Delete(l_item);
						DisplayItemsDefault();
					}
					
				}});
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
			return false;
		}};
	
	
	private  void InicialComponent() {
		btnSearch=(ImageButton)findViewById(R.id.ReportStyle01_btnSearch);
		btnSearch.setOnClickListener(btnSearch_Click);
		lblCondition=(TextView)findViewById(R.id.ReportStyle01_lblCondition);
		lblResult=(TextView)findViewById(R.id.ReportStyle01_lblResult);
		lstDetail=(ListView)findViewById(R.id.ReportStyle01_lstMenu);
		lstDetail.setOnItemLongClickListener(lstDetail_LongClick);
		lstDetail.setCacheColorHint(0);
		lblResult.setText("");
	}
	ImageButton btnSearch=null;
	TextView lblCondition=null;
	TextView lblResult=null;
	ListView lstDetail=null;
	

}
