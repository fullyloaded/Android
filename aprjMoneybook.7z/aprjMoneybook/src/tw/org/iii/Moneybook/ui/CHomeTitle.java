package tw.org.iii.Moneybook.ui;
public class CHomeTitle {

	private double iv_dblIncome;
	private double iv_dblPayment;
	private String iv_strTitle="";
	private String iv_strSubTitle="";
	private int iv_intPaymentCount;
	private int iv_intIncomeCount;
	
	public void AddPaymentCount(int p_intCount){
		iv_intPaymentCount+=p_intCount;
	}
	public void AddIncomeCount(int p_intCount){
		iv_intIncomeCount+=p_intCount;
	}
	public void SetIncome(double iv_dblIncome) {
		this.iv_dblIncome = iv_dblIncome;
	}
	public double GetIncome() {
		return iv_dblIncome;
	}
	public void SetPayment(double iv_dblPayment) {
		this.iv_dblPayment = iv_dblPayment;
	}
	public double GetPayment() {
		return iv_dblPayment;
	}
	public void SetTitle(String iv_strTitle) {
		this.iv_strTitle = iv_strTitle;
	}
	public String GetTitle() {
		return iv_strTitle;
	}
	public void SetSubTitle(String iv_strSubTitle) {
		this.iv_strSubTitle = iv_strSubTitle;
	}
	public String GetSubTitle() {
		return iv_strSubTitle;
	}
	public void SetPaymentCount(int iv_intPaymentCount) {
		this.iv_intPaymentCount = iv_intPaymentCount;
	}
	public int GetPaymentCount() {
		return iv_intPaymentCount;
	}
	public void SetIncomeCount(int iv_intIncomeCount) {
		this.iv_intIncomeCount = iv_intIncomeCount;
	}
	public int GetIncomeCount() {
		return iv_intIncomeCount;
	}
}
