package tw.org.iii.Moneybook.ui;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CAccount;
import tw.org.iii.Moneybook.lib.da.CCode;
import tw.org.iii.Moneybook.lib.da.CCodeQueryKey;
import tw.org.iii.Moneybook.lib.da.CItem;
import tw.org.iii.Moneybook.lib.util.CDateUtility;
import tw.org.iii.Moneybook.ui.report.ActChart;
import tw.org.iii.Moneybook.ui.report.ActDailyDetail;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class ActHome extends Activity {
	public final static int MENUITEM_SETTING=1;
	public final static int MENUITEM_ABOUT=2;
		
	private void AddCatalogSub(String p_strKey,String p_strCatalogName,String p_strCatalogSubKey, String[] p_strCatalogSub){
		CCodeQueryKey l_key=new CCodeQueryKey();
		l_key.AddTypeEqual(p_strKey);
		l_key.AddKeyEqual(p_strKey);
		l_key.AddValueEqual(p_strCatalogName);
		CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(l_key);		
		if(l_codes==null)			
			return;
		
		for(int i=0;i<p_strCatalogSub.length;i++){
			CDictionary.CCONTEXT.GetCodeFactory().Create(p_strCatalogSubKey,String.valueOf( l_codes[0].GetId()),p_strCatalogSubKey,p_strCatalogSub[i]);
		}
	}
	
	private void CreateDefaultCode(){
		// create account
			CAccount l_account=CDictionary.CCONTEXT.GetAccountFactory().Create();
			l_account.SetName((String)getResources().getString(R.string.item_cash));
			l_account.SetType(l_account.GetName());
			CDictionary.CCONTEXT.GetAccountFactory().Update(l_account);
			l_account=CDictionary.CCONTEXT.GetAccountFactory().Create();
			l_account.SetName("�H�Υd");//((String)getResources().getString(R.string.item_creditcard));
			l_account.SetType(l_account.GetName());
			CDictionary.CCONTEXT.GetAccountFactory().Update(l_account);
		// create catalog
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�\�����~");
			
			CCodeQueryKey l_key=new CCodeQueryKey();
			l_key.AddTypeEqual(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT);
			l_key.AddKeyEqual(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT);
			l_key.AddValueEqual("�\�����~");
			CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(l_key);
			Log.d(CDictionary.DEBUG_TAG,l_key.ToSqlCommand());
			if(l_codes!=null){
				CDictionary.CCONTEXT.GetCodeFactory().Create(
						CDictionary.EDITOR_TYPE_DEFAULT,
						CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, 
						String.valueOf(l_codes[0].GetId()),"�\�����~");
			}
			
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�\�����~",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"���\","���\","�U�ȯ�","���\","�d�]","����","�s��"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","��q����");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"��q����",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�j���B��","�o�O","�ײz�O�i","�@��","�����O"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�q�H�q�T");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�q�H�q�T",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�q�ܶO","����q�ܶO","�����O","�q�T�˸m","���u�q���O"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�𶢮T��");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�𶢮T��",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�E�\","�ȹC�װ�","�d���_��","�B�ʰ���","3C���~","�qť�v��",});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�i�׾ǲ�");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�i�׾ǲ�",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�Ч����y","�i�׽ҵ{","�u�W�ǲ�"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�H������");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�H������",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�e§","��߬��]","���˶O","����","�ɶU"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�����O��");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�����O��",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�����O","�Ұ��O","���e�i��"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","���īO�I");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"���īO�I",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�O�I�O","�����I��","����O","�|��","�@��"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","���z�]");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"���z�]",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"����w�B","�Ѳ�","�ֳz����"});			
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�~�a���~");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�~�a���~",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"�ͬ��Ϋ~","���q�˴�","�Я�","�жU"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","�i�f");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,"�i�f",CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT,new String[]{"����","�l��"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT,CDictionary.EDITOR_TYPE_CATALOG_PAYMENT, "","��L���O");
			
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_INCOME,CDictionary.EDITOR_TYPE_CATALOG_INCOME, "","�u�@�~��");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_INCOME,"�u�@�~��",CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME,new String[]{"�~��","��¾","����"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_INCOME,CDictionary.EDITOR_TYPE_CATALOG_INCOME, "","�t�����I");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_INCOME,"�t�����I",CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME,new String[]{"���q1","���q2"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_INCOME,CDictionary.EDITOR_TYPE_CATALOG_INCOME, "","�g�@�Z�O");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_INCOME,"�g�@�Z�O",CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME,new String[]{"���y�ۧ@","���ֳЧ@","�n��]�p"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_INCOME,CDictionary.EDITOR_TYPE_CATALOG_INCOME, "","���z�]");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_INCOME,"���z�]",CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME,new String[]{"�Q��","����Ѳ�","�n��]�p"});
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_CATALOG_INCOME,CDictionary.EDITOR_TYPE_CATALOG_INCOME, "","��L���O");
			AddCatalogSub(CDictionary.EDITOR_TYPE_CATALOG_INCOME,"��L���O",CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME,new String[]{"����"});
		// create project
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_PROJECT,CDictionary.EDITOR_TYPE_PROJECT, "","�X�t");
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_PROJECT,CDictionary.EDITOR_TYPE_PROJECT, "","�|�८��");
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_PROJECT,CDictionary.EDITOR_TYPE_PROJECT, "","�ʳf�P�P");
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_PROJECT,CDictionary.EDITOR_TYPE_PROJECT, "","�X��ȹC");
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_PROJECT,CDictionary.EDITOR_TYPE_PROJECT, "","���B���");
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.EDITOR_TYPE_PROJECT,CDictionary.EDITOR_TYPE_PROJECT, "","�ĶR");
		// create default code			
			CDictionary.CCONTEXT.GetCodeFactory().Create(CDictionary.KEY_DEFAULTCODE_ISEXECUTED,CDictionary.KEY_DEFAULTCODE_ISEXECUTED, "","");
	}
	private boolean IsDefaultCodeCreated(){
		CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByKeyAndType(
				CDictionary.KEY_DEFAULTCODE_ISEXECUTED,
				CDictionary.KEY_DEFAULTCODE_ISEXECUTED);
		return (l_codes!=null);
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        InicialComponent();
        CDictionary.CCONTEXT=new CContext(this);
        if(!IsDefaultCodeCreated())
        	CreateDefaultCode();     
        DisplayReport();
    }
    @Override
	protected void onResume() {
    	DisplayReport();
		super.onResume();
	}
	private void DisplayReport() {
    	Calendar l_calendarStartOfMonth=Calendar.getInstance();
    	l_calendarStartOfMonth.set(Calendar.DATE, 1);
    	
    	Calendar l_calendarEndOfMonth=CDateUtility.GetLastDateOfMonth(Calendar.getInstance());
    	
    	CItem[] l_items=CDictionary.CCONTEXT.GetItemFactory().GetItemByDateRange(
    			CDateUtility.ToDateDbString(l_calendarStartOfMonth)+"000000",
    			CDateUtility.ToDateDbString(l_calendarEndOfMonth)+"999999"
			);
    	
    	CHomeTitle l_today=new CHomeTitle();    	
    	l_today.SetSubTitle(CDateUtility.GetFormatedDateToday());
    	CHomeTitle l_month=new CHomeTitle();
    	
    	l_month.SetSubTitle(CDateUtility.GetFormatedDate(l_calendarStartOfMonth)+"~"+
    			CDateUtility.GetFormatedDate(l_calendarEndOfMonth)    			
    	);
    	
    	if(l_items!=null){
    		for(int i=0;i<l_items.length;i++){
    			if(l_items[i].GetMoney()<0){
    				if(l_items[i].GetDate().substring(0,8).equals(CDateUtility.GetTodayDbString())){
    					l_today.SetPayment(l_today.GetPayment()+l_items[i].GetMoney());    				
    					l_today.AddPaymentCount(1);
    				}
    				l_month.SetPayment(l_month.GetPayment()+l_items[i].GetMoney());
    			}
    			else{
    				if(l_items[i].GetDate().substring(0,8).equals(CDateUtility.GetTodayDbString())){
    					l_today.SetIncome(l_today.GetIncome()+l_items[i].GetMoney());    				
    					l_today.AddIncomeCount(1);
    				}
    				l_month.SetIncome(l_month.GetIncome()+l_items[i].GetMoney());
    			}
			}
    	}    	
    	btnPayment.setText(R.string.home_new_payment);
    	btnIncome.setText(R.string.home_new_income);
    	DecimalFormat l_format=new DecimalFormat("###,###,###,###");
    	l_today.SetTitle("����έp $"+l_format.format(l_today.GetIncome()+l_today.GetPayment()));
    	l_month.SetTitle("����έp $"+l_format.format(l_month.GetIncome()+l_month.GetPayment()));
    	if(l_today.GetPaymentCount()>0){
    		btnPayment.setText(btnPayment.getText().toString()+" ("+String.valueOf(l_today.GetPaymentCount())+")");
    	}
    	if(l_today.GetIncomeCount()>0){
    		btnIncome.setText(btnIncome.getText().toString()+" ("+String.valueOf(l_today.GetIncomeCount())+")");
    	}
		List<CHomeTitle> l_list=new ArrayList<CHomeTitle>();				
		l_list.add(l_today);
		l_list.add(l_month);
		
		CHomeListAdapter l_adapter=new  CHomeListAdapter(ActHome.this,0,l_list);
		lstMenu.setAdapter(l_adapter);
		//
		
	}
	/*
     * Description�G�Ұʦ�ƾ�
     */
    OnClickListener btnIncome_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {			
			ActItemEditor.EDITOR_MODE=CDictionary.ITEMEDITOR_MODE_INCOME;
			Intent l_intent=new Intent(ActHome.this,ActItemEditor.class);
			startActivity(l_intent);						
		}    	
    };    
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
    	menu.add(0,this.MENUITEM_SETTING,1,R.string.home_menu_item_setting);
    	menu.add(0,this.MENUITEM_ABOUT,1,R.string.home_menu_item_about);
    	
		return super.onCreateOptionsMenu(menu);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if(item.getItemId()==ActHome.MENUITEM_ABOUT)
		{
			String l_str="���n�鬰�n�ϸ굦�|Android�ҵ{�m�߹�@�D��\r\n";
			l_str         +="�ϥΪ̭Y�������ĳ�A�i�H�����ܪA�ȫH�c�C\r\n";
			l_str         +="��h���������ҵ{�A�ФW�굦�|�x������C\r\n";
			l_str         +="\r\n\r\n�}�o�H���GMarco Tsai\r\n";
			ActAbout.GLOBAL_MESSAGE=l_str;
			ActAbout.GLOBAL_HYPERLINKTITLE="�I���s�� �n�ϸ굦�|�Ʀ�Ш|��s�� ����";
			ActAbout.GLOBAL_URL="http://www.iiiedu.org.tw/south/Training/All/Android_soho.htm";
			
			ActAbout.GLOBAL_HYPERLINKTITLE2="\r\n�I���s�� �_�ϸ굦�|�Ʀ�Ш|��s�� ����";
			ActAbout.GLOBAL_URL2="http://www.iiiedu.org.tw/taipei/aspro/course_c.asp?qcno=DEM746T&qvendor=99";
			
			Intent l_intent=new Intent(ActHome.this,ActAbout.class);
			startActivity(l_intent);			
		}
		if(item.getItemId()==ActHome.MENUITEM_SETTING)
		{
			String l_str="���\��|���}��";
			ActAbout.GLOBAL_MESSAGE=l_str;
			Intent l_intent=new Intent(ActHome.this,ActAbout.class);
			startActivity(l_intent);	
		}
		return super.onOptionsItemSelected(item);
	}
	/*
     * Description�G�Ұʦ�ƾ�
     */
    OnClickListener btnReport_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {

			Bundle l_bundle=new Bundle();
			l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, ActMenu.MODE_REPORT);
			
			Intent l_intent=new Intent(ActHome.this,ActMenu.class);
			l_intent.putExtras(l_bundle);
			startActivityForResult(l_intent,CDictionary.ACTIVEID_MENU);
		}    	
    }; 
    OnClickListener btnPayment_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			
			ActItemEditor.EDITOR_MODE=CDictionary.ITEMEDITOR_MODE_PAYMENT;
			Intent l_intent=new Intent(ActHome.this,ActItemEditor.class);
			startActivity(l_intent);	
		}    	
    };        
    OnClickListener btnBasicdata_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Bundle l_bundle=new Bundle();
			l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, ActMenu.MODE_BASICDATA);
			
			Intent l_intent=new Intent(ActHome.this,ActMenu.class);
			l_intent.putExtras(l_bundle);
			startActivityForResult(l_intent,CDictionary.ACTIVEID_MENU);
		}    	
    };        
    
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		try{
			
			if(requestCode==CDictionary.ACTIVEID_MENU){
				ActivityResultForMenu(resultCode, data);
			}
			if(requestCode==CDictionary.ACTIVEID_CODEEDITOR){		
				ActivityResultForCodeEditor(data);	

			}
		}catch(Exception ex){
			
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void ActivityResultForCodeEditor(Intent data) {
		if(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT.equals(ActCodeEditor.EDITOR_TYPE ) ||
			CDictionary.EDITOR_TYPE_CATALOG_INCOME.equals(ActCodeEditor.EDITOR_TYPE) 	){
			
				int l_intCatalogId=data.getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);
				if(l_intCatalogId>0){ // ���ܨϥΪ̭n�s�覸����
					if(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT.equals(ActCodeEditor.EDITOR_TYPE ) ){
						ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT;
					}else if(CDictionary.EDITOR_TYPE_CATALOG_INCOME.equals(ActCodeEditor.EDITOR_TYPE ) ){
						ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME;
					}							
					Log.d(CDictionary.DEBUG_TAG,"�ǳƶi�J�l���O"+ActCodeEditor.EDITOR_TYPE);
					String l_strCatalogName=data.getExtras().getString(CDictionary.BUNDLE_KEY_MENU_TYPE);
					Bundle l_bundle=new Bundle();
					l_bundle.putString(CDictionary.BUNDLE_KEY_MENU_TYPE, l_strCatalogName);
					l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE,l_intCatalogId);
					Intent l_intent=new Intent(ActHome.this,ActCodeEditor.class);			
					l_intent.putExtras(l_bundle);
					startActivityForResult(l_intent,CDictionary.ACTIVEID_CODEEDITOR);
				}
									
		}else if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals(ActCodeEditor.EDITOR_TYPE ) ||
				CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals(ActCodeEditor.EDITOR_TYPE) 	){
			
			if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals(ActCodeEditor.EDITOR_TYPE ) ){
				ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_PAYMENT;
			}else if(CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals(ActCodeEditor.EDITOR_TYPE ) ){
				ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_INCOME;
			}
			
			Intent l_intent=new Intent(ActHome.this,ActCodeEditor.class);			
			startActivityForResult(l_intent,CDictionary.ACTIVEID_CODEEDITOR);
		}
	}

	private void ActivityResultForMenu(int resultCode, Intent data) {
		int l_int=data.getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);
		if(resultCode==ActMenu.MODE_BASICDATA){				
			if(l_int==0){// show payment code maintain editor
				ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_PAYMENT;					
			}else if(l_int==1){
				ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_INCOME;				
			}else if(l_int==2){
				ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_PROJECT;				
			}else if(l_int==3){
				Intent l_intent=new Intent(ActHome.this,ActAccountList.class);					
				startActivityForResult(l_intent,CDictionary.ACTIVEID_ACCOUNTLIST);
				return;
			}
			Intent l_intent=new Intent(ActHome.this,ActCodeEditor.class);					
			startActivityForResult(l_intent,CDictionary.ACTIVEID_CODEEDITOR);
		}else if(resultCode==ActMenu.MODE_REPORT){
			if(l_int==0){// ���Ӫ�
				Bundle l_bundle=new Bundle();						
				l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_DAILY);																				
				Intent l_intent=new Intent(ActHome.this,ActDailyDetail.class);
				l_intent.putExtras(l_bundle);
				startActivity(l_intent);
			}						
			else if(l_int==1){// ��έp
				Bundle l_bundle=new Bundle();						
				l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_MONTH);																				
				Intent l_intent=new Intent(ActHome.this,ActDailyDetail.class);
				l_intent.putExtras(l_bundle);
				startActivity(l_intent);
			}								
			else if(l_int==2){// �M�קO��X�έp
				Bundle l_bundle=new Bundle();						
				l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_PROJECT_PAYMENT);																				
				Intent l_intent=new Intent(ActHome.this,ActChart.class);
				l_intent.putExtras(l_bundle);
				startActivity(l_intent);
			}								
			else if(l_int==3){// �M�קO��X�έp
				Bundle l_bundle=new Bundle();						
				l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_ACCOUNT_PAYMENT);																				
				Intent l_intent=new Intent(ActHome.this,ActChart.class);
				l_intent.putExtras(l_bundle);
				startActivity(l_intent);
			} else if(l_int==4){// �M�קO��X�έp
				Bundle l_bundle=new Bundle();						
				l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_CATALOG_PAYMENT);																				
				Intent l_intent=new Intent(ActHome.this,ActChart.class);
				l_intent.putExtras(l_bundle);
				startActivity(l_intent);
			}		
		}
	}

	
	OnItemClickListener lstMenu_ItemClick=new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			
			Bundle l_bundle=new Bundle();
			if(arg2==0){// �������
				l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_DAILY);								
			}else if(arg2==1){
				l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, CDictionary.REPORT_MODE_MONTH);				
			}
			Intent l_intent=new Intent(ActHome.this,ActDailyDetail.class);
			l_intent.putExtras(l_bundle);
			startActivity(l_intent);
			
		}
	};
	
	
	private void InicialComponent() {
		btnIncome=(Button)findViewById(R.id.btnIncome);
		btnIncome.setOnClickListener(btnIncome_Click);
		btnPayment=(Button)findViewById(R.id.btnPayament);
		btnPayment.setOnClickListener(btnPayment_Click);
		btnReport=(Button)findViewById(R.id.btnReport);
		btnReport.setOnClickListener(btnReport_Click);
		btnBasicdata=(Button)findViewById(R.id.btnBasicData);
		btnBasicdata.setOnClickListener(btnBasicdata_Click);
		lstMenu=(ListView)findViewById(R.id.lstMenu);
		lstMenu.setOnItemClickListener(lstMenu_ItemClick);
		lstMenu.setCacheColorHint(0);
	}
	Button btnIncome=null;
	Button btnPayment=null;
	Button btnReport=null;
	Button btnBasicdata=null;
	ListView lstMenu=null;
}