package tw.org.iii.Moneybook.ui.chart;

public class CChartItem {
	private double iv_dblData=0;
	private int iv_intColor=0;
	private String iv_strTitle="";
	private String iv_strTitleSub="";
	public void SetData(double iv_dblData) {
		this.iv_dblData = iv_dblData;
	}
	public double GetData() {
		return iv_dblData;
	}
	public void SetColor(int iv_intColor) {
		this.iv_intColor = iv_intColor;
	}
	public int GetColor() {
		return iv_intColor;
	}
	public void SetTitle(String iv_strTitle) {
		this.iv_strTitle = iv_strTitle;
	}
	public String GetTitle() {
		return iv_strTitle;
	}
	private void SetTitleSub(String iv_strTitleSub) {
		this.iv_strTitleSub = iv_strTitleSub;
	}
	private String GetTitleSub() {
		return iv_strTitleSub;
	}
	
}
