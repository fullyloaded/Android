package tw.org.iii.Moneybook.ui;

import tw.org.iii.Moneybook.R;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

public class ActMenu extends ListActivity {
	public final static int MODE_BASICDATA=1;
	public final static int MODE_REPORT=2;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        InicialComponent();
    }
    @Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
    	int l_intKey=getIntent().getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);
		Intent l_intent=new Intent();
		Bundle l_bundle=new Bundle();
		l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, position);
		l_intent.putExtras(l_bundle);		
		setResult(l_intKey,l_intent);		
		finish();
		super.onListItemClick(l, v, position, id);
	}
	public void InicialComponent(){
    	int l_intKey=getIntent().getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);
    	ListAdapter l_adapter=null;
    	if(MODE_BASICDATA==l_intKey){    	
    		String[] l_strs=getResources().getStringArray(R.array.menu_basicdata);
    		l_adapter=new ArrayAdapter<String>(
    			this,android.R.layout.simple_list_item_single_choice,l_strs);
    	}else if(MODE_REPORT==l_intKey){    	
    		String[] l_strs=getResources().getStringArray(R.array.menu_report);
    		l_adapter=new ArrayAdapter<String>(
    			this,android.R.layout.simple_list_item_single_choice,l_strs);
    	}
    		
    	if(l_adapter!=null)
    		setListAdapter(l_adapter);    		
    }
}
