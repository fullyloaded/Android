package tw.org.iii.Moneybook.ui.common;

import java.text.DecimalFormat;
import java.util.ArrayList;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.util.CStringUtility;
import tw.org.iii.Moneybook.ui.CDictionary;
import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ActCalculatorInput extends Activity {

	public static String INPUT_TYPE="";
	public final static String INPUT_TYPE_STRING="INPUT_TYPE_STRING";
	public final static String INPUT_TYPE_DOUBLE="INPUT_TYPE_DOUBLE";
	
	private boolean iv_blnIsDot;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.calculatorinput);
		InicialComponent();
	}
	
	void VibrateStart(long p_lng){
		Vibrator l_vib=(Vibrator)getSystemService(Service.VIBRATOR_SERVICE);
		l_vib.vibrate(p_lng);

	}
	/*<Description>
	 * 		1.�N�ϥΪ̿�J���r��parse��ArrList
	 * 		
	 * </Description>
	 * <Parameter name="p_str" type="String">�]�t"X�P/"���r��</Parameter>
	 * <Return type="double">�B��ᵲ�G</Return>
	 * <Date>2012-05-20</Date>
	 */
	
	private double GetResult(){
		String l_str=""+lblNumbers.getText().toString();
		try{
			double l_dbl=Double.parseDouble(l_str);
			return l_dbl;
		}catch(Exception ex){
			
		}
		String l_strItem="";
		String l_strLiteral="";
		
		// parseAll item into ArrayList
		ArrayList<String> l_list=new ArrayList<String>();
		for(int i=0;i<l_str.length();i++){
			l_strLiteral=l_str.substring(i,i+1);
			if("+".equals(l_strLiteral) ||
					"-".equals(l_strLiteral) ){
				l_list.add(l_strItem);
				l_list.add(l_strLiteral);
				l_strItem="";
				l_strLiteral="";
			}
			l_strItem+=l_strLiteral;
		}
		if(!IsOperator(CStringUtility.GetLatestChar(lblNumbers.getText().toString())))
			l_list.add(l_strItem);
		
		String l_strTemp=(String)l_list.get(0);
		double l_dblResult=GetResultByDivString(l_strTemp);				
		for(int i=0;i<l_list.size();i++){
			if((i+2)>=l_list.size())
				break;
			String l_strOp=(String)l_list.get(i+1);
			String l_strNO2=(String)l_list.get(i+2);
			double l_dblNO2=GetResultByDivString(l_strNO2);
			if("+".equals(l_strOp) ){
				l_dblResult+=l_dblNO2;
			}else if("-".equals(l_strOp) ){
				l_dblResult-=l_dblNO2;
			}
			i++;	
		}

		
		return  l_dblResult;
		

	}
	/*<Description>
	 * 		1.�p�G�Ѽ�p_str���]�t"X�P/"�A�h������double�Ǧ^
	 * 		2.�Ƕi�Ӫ��r��i��]�tX�P/�A�ҥH���N�r����Φ��Ʀr�P�B��Ÿ�
	 * 		3.�̷ӹB��Ÿ��⵲�G�Ǧ^
	 * </Description>
	 * <Parameter name="p_str" type="String">�]�t"X�P/"���r��</Parameter>
	 * <Return type="double">�B��ᵲ�G</Return>
	 * <Date>2012-05-20</Date>
	 */
    private double GetResultByDivString(String p_str){
    	try{
    		if(p_str.indexOf("X")<0 && p_str.indexOf("/")<0)
    			return Double.parseDouble(p_str);
    	}catch(Exception ex){
    		return 0;
    	}
		String l_strItem="";
		String l_strLiteral="";
		ArrayList<String> l_list=new ArrayList<String>();
		for(int i=0;i<p_str.length();i++){
			l_strLiteral=p_str.substring(i,i+1);
			if("X".equals(l_strLiteral) ||
					"/".equals(l_strLiteral) ){
				l_list.add(l_strItem);
				l_list.add(l_strLiteral);
				l_strItem="";
				l_strLiteral="";
			}
			l_strItem+=l_strLiteral;
		}
		if(!IsOperator(CStringUtility.GetLatestChar(lblNumbers.getText().toString())))
			l_list.add(l_strItem);
		
		String l_strTemp=(String)l_list.get(0);
		double l_dblResult=Double.parseDouble(l_strTemp);
		for(int i=0;i<l_list.size();i++){
			if((i+2)>=l_list.size())
				break;
			String l_strOp=(String)l_list.get(i+1);
			String l_strNO2=(String)l_list.get(i+2);
			if("X".equals(l_strOp) ){
				l_dblResult*=Double.parseDouble(l_strNO2);
			}else if("/".equals(l_strOp) ){
				l_dblResult/=Double.parseDouble(l_strNO2);
			}
			i++;	
		}		
		
		return l_dblResult;
    }
	private void AddCharTo(String p_str){
		String l_str=""+lblNumbers.getText().toString();
		l_str+=p_str;
		lblNumbers.setText(l_str);
	}
	/* <Description>�P�_�ѼƬO�_���B��Ÿ� </Description>
	 * <Parameter name="p_str" type="String">�]�t"X�P/"���r��</Parameter>
	 * <Return type="boolean">�B��ᵲ�G</Return>
	 * <Date>2012-05-20</Date>
	 */
	private boolean IsOperator(String p_str){
		return ("+".equals(p_str) ||
				"-".equals(p_str) ||
				"X".equals(p_str) ||
				"/".equals(p_str) 				
				);
	}

	private void NumberClick( String p_str ){
		if(ActCalculatorInput.INPUT_TYPE_STRING.equals(ActCalculatorInput.INPUT_TYPE)){
			AddCharTo(p_str);
			return;
		}else{
			if(!"0".equals(lblNumbers.getText().toString())){
				AddCharTo(p_str);
			}
			else{
				lblNumbers.setText(p_str);
			}
		}
	}
	
	private void OperatorClick(String p_str){
		String l_str=CStringUtility.GetLatestChar(lblNumbers.getText().toString());		
		iv_blnIsDot=false;
		
		if(!"+".equals(l_str) &&
				!"-".equals(l_str) &&
				!"X".equals(l_str) &&
				!"/".equals(l_str) &&
				!"".equals(l_str) 
				){			
			lblNumbers.setText(lblNumbers.getText()+p_str);
		}else if(IsOperator(l_str)){
			lblNumbers.setText(CStringUtility.GetRight(lblNumbers.getText().toString(),
					lblNumbers.getText().toString().length()-1)+p_str);
		}
		
	}
	  OnClickListener btn0_Click=new OnClickListener(){
			public void onClick(View arg0) {				
				if(ActCalculatorInput.INPUT_TYPE_STRING.equals(ActCalculatorInput.INPUT_TYPE)){
					AddCharTo("0");
					return;
				}
				if(!"0".equals(lblNumbers.getText().toString())){
					AddCharTo("0");
				}				
		}};
	  OnClickListener btn00_Click=new OnClickListener(){
			public void onClick(View arg0) {
				if(!"0".equals(lblNumbers.getText().toString())){
					AddCharTo("00");
				}
			}};
			
	  OnClickListener btn1_Click=new OnClickListener(){
			public void onClick(View arg0) {
				NumberClick("1");		
			}};
			
	  OnClickListener btn2_Click=new OnClickListener(){
			public void onClick(View arg0) {
				NumberClick("2");
			}};
	  OnClickListener btn3_Click=new OnClickListener(){
			public void onClick(View arg0) {
				NumberClick("3");
				
			}};
	  OnClickListener btn4_Click=new OnClickListener(){
			public void onClick(View arg0) {
		    
				NumberClick("4");
			}};	
			OnClickListener btn5_Click=new OnClickListener(){
				public void onClick(View arg0) {
			    
					NumberClick("5");
				}};
		  OnClickListener btn6_Click=new OnClickListener(){
				public void onClick(View arg0) {
			    
					NumberClick("6");
				}};				
				OnClickListener btn7_Click=new OnClickListener(){
					public void onClick(View arg0) {
						NumberClick("7");
						
					}};
	  OnClickListener btn8_Click=new OnClickListener(){
			public void onClick(View arg0) {
				NumberClick("8");
				
			}};					
		OnClickListener btn9_Click=new OnClickListener(){
			public void onClick(View arg0) {
				NumberClick("9");
				
			}};
		  OnClickListener btnDiv_Click=new OnClickListener(){
				public void onClick(View arg0) {			    
					OperatorClick("/");
				}};						
			OnClickListener btnMult_Click=new OnClickListener(){
				public void onClick(View arg0) {
			    
					OperatorClick("X");
				}};
		  OnClickListener btnMin_Click=new OnClickListener(){
				public void onClick(View arg0) {
				    
					OperatorClick("-");
			}};							
		OnClickListener btnPlus_Click=new OnClickListener(){
			public void onClick(View arg0) {
		    
				
				OperatorClick("+");
				
			}};
			  OnClickListener btnDot_Click=new OnClickListener(){
						public void onClick(View arg0) {
							if(!iv_blnIsDot)
							{
								iv_blnIsDot=true;
								AddCharTo(".");
							}
							
						}};						
			OnClickListener btnClear_Click=new OnClickListener(){
					public void onClick(View arg0) {
				    
						lblNumbers.setText("");
					}};
			  OnClickListener btnBackspace_Click=new OnClickListener(){
					public void onClick(View arg0) {
						String l_str=""+lblNumbers.getText().toString();
						if(l_str.length()>0)							
							lblNumbers.setText(l_str.substring(0,l_str.length()-1));
					}};							
				OnClickListener btnHis_Click=new OnClickListener(){
						public void onClick(View arg0) {
					    
							
						}};
						

						
	OnClickListener btnEquals_Click=new OnClickListener(){
			public void onClick(View arg0) {
				DecimalFormat l_format=new DecimalFormat("#.#");				
				lblNumbers.setText(l_format.format(GetResult()));
	}};
			
	OnClickListener btnOk_Click=new OnClickListener(){
		public void onClick(View arg0) {
			VibrateStart(100);
			Bundle l_bundle=new Bundle();
			if(INPUT_TYPE_STRING.equals(INPUT_TYPE))
				l_bundle.putString(CDictionary.BUNDLE_KEY_MENU_TYPE,lblNumbers.getText().toString());
			else 
				l_bundle.putDouble(CDictionary.BUNDLE_KEY_MENU_TYPE,GetResult() );
			Intent l_intent=new Intent();
			l_intent.putExtras(l_bundle);
			setResult(1,l_intent);
			INPUT_TYPE="";
			finish();	
	}};
			  OnClickListener btnCancel_Click=new OnClickListener(){
					public void onClick(View arg0) {			
						VibrateStart(100);
						finish();
					}};							

					private void InicialComponent() {

						lblNumbers=(TextView)findViewById(R.id.CalculatorInput_lblNumber);
						btn0=(ImageView)findViewById(R.id.btn0);
						btn0.setOnClickListener(btn0_Click);
						btn00=(ImageView)findViewById(R.id.btn00);
						btn00.setOnClickListener(btn00_Click);
						btn1=(ImageView)findViewById(R.id.btn1);
						btn1.setOnClickListener(btn1_Click);
						btn2=(ImageView)findViewById(R.id.btn2);
						btn2.setOnClickListener(btn2_Click);
						btn3=(ImageView)findViewById(R.id.btn3);
						btn3.setOnClickListener(btn3_Click);
						btn4=(ImageView)findViewById(R.id.btn4);
						btn4.setOnClickListener(btn4_Click);
						btn5=(ImageView)findViewById(R.id.btn5);
						btn5.setOnClickListener(btn5_Click);
						btn6=(ImageView)findViewById(R.id.btn6);
						btn6.setOnClickListener(btn6_Click);
						btn7=(ImageView)findViewById(R.id.btn7);
						btn7.setOnClickListener(btn7_Click);
						btn8=(ImageView)findViewById(R.id.btn8);
						btn8.setOnClickListener(btn8_Click);
						btn9=(ImageView)findViewById(R.id.btn9);
						btn9.setOnClickListener(btn9_Click);
						btnDiv=(ImageView)findViewById(R.id.btnDiv);
						btnDiv.setOnClickListener(btnDiv_Click);
						btnMult=(ImageView)findViewById(R.id.btnMult);
						btnMult.setOnClickListener(btnMult_Click);
						btnMin=(ImageView)findViewById(R.id.btnMin);
						btnMin.setOnClickListener(btnMin_Click);
						btnPlus=(ImageView)findViewById(R.id.btnPlus);
						btnPlus.setOnClickListener(btnPlus_Click);
						btnEquals=(ImageView)findViewById(R.id.btnEquals);
						btnEquals.setOnClickListener(btnEquals_Click);
						btnClear=(ImageView)findViewById(R.id.btnClear);
						btnClear.setOnClickListener(btnClear_Click);
						btnBackspace=(ImageView)findViewById(R.id.btnBackspace);
						btnBackspace.setOnClickListener(btnBackspace_Click);
						btnHis=(ImageView)findViewById(R.id.btnHis);
						btnHis.setOnClickListener(btnHis_Click);
						btnDot=(ImageView)findViewById(R.id.btnDot);
						btnDot.setOnClickListener(btnDot_Click);
						btnOk=(Button)findViewById(R.id.CalculatorInput_btnOk);
						btnOk.setOnClickListener(btnOk_Click);
						btnCancel=(Button)findViewById(R.id.CalculatorInput_btnCancel);
						btnCancel.setOnClickListener(btnCancel_Click);
						
						
						if(getIntent().getExtras()!=null)
						{
							DecimalFormat l_format=new DecimalFormat("0"); 
							double l_dbl=getIntent().getExtras().getDouble(CDictionary.BUNDLE_KEY_MENU_TYPE);
								lblNumbers.setText(l_format.format(l_dbl));
						}
						
					}
		TextView lblNumbers=null;
		ImageView btn0=null;
		ImageView btn1=null;
		ImageView btn2=null;
		ImageView btn3=null;
		ImageView btn4=null;
		ImageView btn5=null;
		ImageView btn6=null;
		ImageView btn7=null;
		ImageView btn8=null;
		ImageView btn9=null;
		ImageView btn00=null;
		ImageView btnDiv=null;
		ImageView btnMult=null;
		ImageView btnMin=null;
		ImageView btnPlus=null;
		ImageView btnEquals=null;
		ImageView btnDot=null;
		ImageView btnClear=null;
		ImageView btnBackspace=null;
		ImageView btnHis=null;
		Button btnOk=null;
		Button btnCancel=null;
		

}
