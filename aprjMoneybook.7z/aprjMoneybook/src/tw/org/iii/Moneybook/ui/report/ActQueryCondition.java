package tw.org.iii.Moneybook.ui.report;

import java.text.DecimalFormat;
import java.util.Calendar;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CAccount;
import tw.org.iii.Moneybook.lib.da.CCode;
import tw.org.iii.Moneybook.lib.da.CItemFactory;
import tw.org.iii.Moneybook.lib.da.CItemQueryKey;
import tw.org.iii.Moneybook.lib.util.CDateUtility;
import tw.org.iii.Moneybook.ui.CDictionary;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class ActQueryCondition extends Activity {
	public static int EDITOR_MODE=0;
	public static String QUERY_CONDITION_KEYS="";
	private CCode[] iv_catalogs;
	private CCode[] iv_catalogSubs;
	private String[] iv_strProjects;
	private CAccount[] iv_accounts;
	private CAccount iv_accountSelected=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.querycondition);
		InicialComponent();
		ResetUiContent();
	}
	
	
	private void ResetUiContent() {
		if(!"".equals(ActQueryCondition.QUERY_CONDITION_KEYS)){
			String[] l_strs=ActQueryCondition.QUERY_CONDITION_KEYS.split("\t");
			Log.d(CDictionary.DEBUG_TAG,"QCK:"+ActQueryCondition.QUERY_CONDITION_KEYS);
			Log.d(CDictionary.DEBUG_TAG,"QCK:"+String.valueOf(l_strs.length));
			txtDateStart.setText(l_strs[0].trim());
			txtDateEnd.setText(l_strs[1].trim());
			txtCatalog.setText(l_strs[2].trim());
			txtCatalogSub.setText(l_strs[3].trim());
			txtProject.setText(l_strs[4].trim());
			if(!"".equals(l_strs[5].trim())){
				iv_accountSelected=new CAccount();
				iv_accountSelected.SetId(Integer.parseInt(l_strs[5].trim()));
				btnAccount.setText(l_strs[6].trim());
			}
		}
		
	}


	private boolean IsUiValidated() {
		String l_str="";
	
		if("".equals(txtDateStart.getText().toString()))
			l_str+="\r\n��������J���";
		if(txtDateStart.getText().toString().length()!=10)
			l_str+="\r\n����J������榡���~�A�����OYYYY-MM-DD";
		if(!"".equals(l_str))
			CDictionary.CCONTEXT.ShowMessage(this,l_str,"�������");
			
			return "".equals(l_str);
	}
	
    
	OnClickListener btnOk_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			if(IsUiValidated()){
				Bundle l_bundle=new Bundle();
				CItemQueryKey l_key=new CItemQueryKey();
				if(!"".equals(txtProject.getText().toString())){
					l_key.AddProjectEqual(txtProject.getText().toString());
					l_bundle.putString(CItemFactory.FIELD_PROJECT, txtProject.getText().toString());
				}
				if(!"".equals(btnAccount.getText().toString())){
					if(iv_accountSelected!=null){
						l_key.AddProjectEqual(String.valueOf( iv_accountSelected.GetId()));
						l_bundle.putString(CItemFactory.FIELD_ACCOUNT, iv_accountSelected.GetName());
					}
				}
				if(!"".equals(txtCatalogSub.getText().toString()))
					l_key.AddCatalogEqual(txtCatalogSub.getText().toString());
				if(!"".equals(txtCatalog.getText().toString())){
					l_key.AddCatalogEqual(txtCatalog.getText().toString());
					l_bundle.putString(CItemFactory.FIELD_CATALOG, txtCatalog.getText().toString());
				}
				if(!"".equals(txtDateStart.getText().toString()) &&
						!"".equals(txtDateEnd.getText().toString()) ){
					l_key.AddDateRange(
						CDateUtility.ToCalendarDate(txtDateStart.getText().toString().replace("-","")),	
						CDateUtility.ToCalendarDate(txtDateEnd.getText().toString().replace("-",""))					
					);
					l_bundle.putString(CItemFactory.FIELD_DATE, 
							txtDateStart.getText().toString()+"~"+txtDateEnd.getText().toString());
				}
				ActQueryCondition.QUERY_CONDITION_KEYS=txtDateStart.getText().toString()+" \t";
				ActQueryCondition.QUERY_CONDITION_KEYS+=txtDateEnd.getText().toString()+" \t";
				ActQueryCondition.QUERY_CONDITION_KEYS+=txtCatalog.getText().toString()+" \t";
				ActQueryCondition.QUERY_CONDITION_KEYS+=txtCatalogSub.getText().toString()+" \t";
				ActQueryCondition.QUERY_CONDITION_KEYS+=txtProject.getText().toString()+" \t";				
				if(iv_accountSelected!=null){
					ActQueryCondition.QUERY_CONDITION_KEYS+=String.valueOf(iv_accountSelected.GetId())+" \t";
					ActQueryCondition.QUERY_CONDITION_KEYS+=iv_accountSelected.GetName()+" \t";					
				}else{
					ActQueryCondition.QUERY_CONDITION_KEYS+=" \t \t";
				}
					
				
				
				l_bundle.putString(CDictionary.BUNDLE_KEY_MENU_TYPE, l_key.ToSqlCommand());
				Intent l_intent=new Intent();
				l_intent.putExtras(l_bundle);
				setResult(0, l_intent);
				finish();
			}
		}   	
    };      		 
    
    OnClickListener btnCancel_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			finish();
		}    	
    };        

	OnClickListener btnCatalogSub_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Builder l_build=new Builder(ActQueryCondition.this);			
			l_build.setTitle(R.string.title_select_item);
			
			String[] l_strCatalogs=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
			
			if(iv_catalogSubs!=null){
				l_strCatalogs=new String[iv_catalogSubs.length];
				for(int i=0;i<iv_catalogSubs.length;i++){
					l_strCatalogs[i]=iv_catalogSubs[i].GetValue();
				}			
			}
			l_build.setItems(l_strCatalogs, new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {					
						txtCatalogSub.setText(iv_catalogSubs[which].GetValue());				
					}
				}	
			);
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
		}    	
    };  
    
	OnClickListener btnCatalog_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Builder l_build=new Builder(ActQueryCondition.this);			
			l_build.setTitle(R.string.title_select_item);
			
			String[] l_strCatalogs=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
			
			if(iv_catalogs!=null){				
				l_strCatalogs=new String[iv_catalogs.length];			
				for(int i=0;i<iv_catalogs.length;i++){
					l_strCatalogs[i]=iv_catalogs[i].GetValue();
				}			
			}
	
			l_build.setItems(l_strCatalogs, new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
							txtCatalog.setText(iv_catalogs[which].GetValue());
							iv_catalogSubs=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(
									String.valueOf(iv_catalogs[which].GetId()));
									
					}
				}	
			);
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
		}    	
    };  
	OnClickListener btnProject_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Builder l_build=new Builder(ActQueryCondition.this);			
			l_build.setTitle(R.string.title_select_item);
			l_build.setItems(iv_strProjects, new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {											
						txtProject.setText(iv_strProjects[which]);								
					}
				}	
			);
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
		}    	
    };  
    
    OnClickListener btnDateStart_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Calendar l_calendar=Calendar.getInstance();
			
			Dialog l_dialog=new DatePickerDialog( ActQueryCondition.this,
				new DatePickerDialog.OnDateSetListener()
				{								
					public void onDateSet(DatePicker arg0, int arg1,	int arg2, int arg3) 
					{
						DecimalFormat l_format=new DecimalFormat("00");
						txtDateStart.setText(String.valueOf(arg1)+"-"+
								l_format.format(arg2+1)+"-"+
								l_format.format(arg3));
					}				
				},
				l_calendar.get(Calendar.YEAR),
				l_calendar.get(Calendar.MONTH),
				l_calendar.get(Calendar.DATE)
			);
			l_dialog.show();
		}
    };
    OnClickListener btnDateEnd_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Calendar l_calendar=Calendar.getInstance();
			
			Dialog l_dialog=new DatePickerDialog( ActQueryCondition.this,
				new DatePickerDialog.OnDateSetListener()
				{								
					public void onDateSet(DatePicker arg0, int arg1,	int arg2, int arg3) 
					{
						DecimalFormat l_format=new DecimalFormat("00");
						txtDateEnd.setText(String.valueOf(arg1)+"-"+
								l_format.format(arg2+1)+"-"+
								l_format.format(arg3));
					}				
				},
				l_calendar.get(Calendar.YEAR),
				l_calendar.get(Calendar.MONTH),
				l_calendar.get(Calendar.DATE)
			);
			l_dialog.show();
		}
    };
	private void ResetCodeItem() {
		// reset catalog items
		String[] l_strCatalogs=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
		
		if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_INCOME){
			iv_catalogs=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_CATALOG_INCOME);			
		}else {
			iv_catalogs=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT);
		}
		
		if(iv_catalogs!=null){
			String l_str=iv_catalogs[0].GetValue();
			l_strCatalogs=new String[iv_catalogs.length+1];
			l_strCatalogs[0]=l_str;
			for(int i=0;i<iv_catalogs.length;i++){
				l_strCatalogs[i+1]=iv_catalogs[i].GetValue();
			}			
		}
		// reset project  items
		iv_strProjects=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
		CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_PROJECT);
		if(l_codes!=null){
			iv_strProjects=new String[l_codes.length];
			for(int i=0;i<l_codes.length;i++){
				iv_strProjects[i]=l_codes[i].GetValue();
			}			
		}
		
		
	}
	
		OnClickListener btnAccount_Click =new OnClickListener(){
			public void onClick(View arg0) {			
				Builder l_build=new AlertDialog.Builder(ActQueryCondition.this);
				if(iv_accounts==null)
					return;
				String[] l_strTitles=new String[iv_accounts.length];
				for(int i=0;i<l_strTitles.length;i++)
					l_strTitles[i]=iv_accounts[i].GetName()+"("+String.valueOf(iv_accounts[i].GetMoney())+")";
				l_build.setTitle(R.string.title_select_item);
				l_build.setItems(l_strTitles,new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {
						iv_accountSelected=iv_accounts[which];
						btnAccount.setText(iv_accountSelected.GetName());					
					}});
						
				
				Dialog l_dialog=l_build.create();
				l_dialog.show();
			}};

	private  void InicialComponent() {
		btnOk=(Button)findViewById(R.id.ItemEditor_btnOk);
		btnOk.setOnClickListener(btnOk_Click);
		btnCancel=(Button)findViewById(R.id.ItemEditor_btnCancel);
		btnCancel.setOnClickListener(btnCancel_Click);

		txtDateStart=(EditText)findViewById(R.id.ItemEditor_txtDateStart);
		txtDateEnd=(EditText)findViewById(R.id.ItemEditor_txtDateEnd);
		txtCatalog=(EditText)findViewById(R.id.ItemEditor_txtCatalog);
		txtCatalogSub=(EditText)findViewById(R.id.ItemEditor_txtCatalogSub);
		txtProject=(EditText)findViewById(R.id.ItemEditor_txtProject);
		btnCatalog=(ImageButton)findViewById(R.id.ItemEditor_btnCatalog);
		btnCatalog.setOnClickListener(btnCatalog_Click);
		btnDateStart=(ImageButton)findViewById(R.id.ItemEditor_btnCalendarStart);
		btnDateStart.setOnClickListener(btnDateStart_Click);
		btnDateEnd=(ImageButton)findViewById(R.id.ItemEditor_btnCalendarEnd);
		btnDateEnd.setOnClickListener(btnDateEnd_Click);		
		
		btnProject=(ImageButton)findViewById(R.id.ItemEditor_btnProject);
		btnProject.setOnClickListener(btnProject_Click);
		btnAccount=(Button)findViewById(R.id.ItemEditor_btnAccount);
		btnAccount.setOnClickListener(btnAccount_Click);
		btnCatalogSub=(ImageButton)findViewById(R.id.ItemEditor_btnCatalogSub);
		btnCatalogSub.setOnClickListener(btnCatalogSub_Click);
		lblTitle=(TextView)findViewById(R.id.ItemEditor_lblTitle);
		// reset ui information
		Calendar l_calendar=Calendar.getInstance();
		txtDateStart.setText(CDateUtility.GetFormatedDateToday());
		txtDateEnd.setText(CDateUtility.GetFormatedDateToday());
		ResetCodeItem();
		
		// set default information
		CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_DEFAULT);
		
		if(l_codes!=null){			
			for(int i=0 ;i<l_codes.length;i++){
				if(CDictionary.EDITOR_TYPE_PROJECT.equals( l_codes[i].GetKey())){
					txtProject.setText( l_codes[i].GetValue());
				}
				if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_INCOME){
					if(CDictionary.EDITOR_TYPE_CATALOG_INCOME.equals( l_codes[i].GetKey())){
						txtCatalog.setText( l_codes[i].GetValue());
						iv_catalogSubs=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(
								l_codes[i].GetName());
					}
					if(CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals( l_codes[i].GetKey())){
						txtCatalogSub.setText( l_codes[i].GetValue());
					}
				}else if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_PAYMENT){
					if(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT.equals( l_codes[i].GetKey())){
						txtCatalog.setText( l_codes[i].GetValue());
						iv_catalogSubs=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(
								l_codes[i].GetName());
					}
					if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals( l_codes[i].GetKey())){
						txtCatalogSub.setText( l_codes[i].GetValue());
					}				
				}				
				
			}
		}
	}
	
	Button btnOk=null;
	Button btnCancel=null;
	Button btnAccount=null;

	EditText txtDateStart=null;
	EditText txtDateEnd=null;
	EditText txtCatalog=null;
	EditText txtCatalogSub=null;
	EditText txtProject=null;

	TextView lblTitle=null;

	ImageButton btnCatalog=null;
	ImageButton btnCatalogSub=null;
	ImageButton btnProject=null;
	ImageButton btnDateStart=null;
	ImageButton btnDateEnd=null;
}

