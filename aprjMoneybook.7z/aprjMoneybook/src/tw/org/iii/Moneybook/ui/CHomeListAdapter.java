package tw.org.iii.Moneybook.ui;

import java.text.DecimalFormat;
import java.util.List;

import tw.org.iii.Moneybook.R;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class CHomeListAdapter extends ArrayAdapter <CHomeTitle>{
	private LayoutInflater iv_inflater=null;
	private String iv_strPositiveSymbol="+";
	private String iv_strNegativeSymbol="-";
	private OnItemClickListener iv_itemClickListener=null;
	private OnClickListener iv_lblClickListener=null;
	public void SetOnClickListener(OnClickListener p_listener){
		iv_lblClickListener=p_listener;
	}
	public void SetOnItemClickListener(OnItemClickListener p_listener){
		iv_itemClickListener=p_listener;
	}
	public CHomeListAdapter(Context context, int rid,List<CHomeTitle>  p_list) {		
		super(context, rid,p_list);				
		iv_inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);		
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		CHomeTitle l_title=(CHomeTitle)getItem(position);
		View l_view=iv_inflater.inflate(R.layout.homelistviewitem, null);
		
		TextView l_lblTitle=(TextView)l_view.findViewById(R.id.home_lblTitle);
		l_lblTitle.setText(l_title.GetTitle());		
		if(iv_lblClickListener!=null)
			l_lblTitle.setOnClickListener(iv_lblClickListener);
		TextView l_lblSubTitle=(TextView)l_view.findViewById(R.id.home_lblSubTitle);
		l_lblSubTitle.setText(l_title.GetSubTitle());
		if(iv_lblClickListener!=null)
			l_lblSubTitle.setOnClickListener(iv_lblClickListener);
		TextView l_lblIncome=(TextView)l_view.findViewById(R.id.home_lblIncome);
		DecimalFormat l_format=new DecimalFormat("###,###,##0");		
		l_lblIncome.setText(iv_strPositiveSymbol+l_format.format(l_title.GetIncome()));
		TextView l_lblPayment=(TextView)l_view.findViewById(R.id.home_lblPayment);
		if(l_title.GetPayment()>=0)
			l_lblPayment.setText(iv_strNegativeSymbol+l_format.format(l_title.GetPayment()));
		else
			l_lblPayment.setText(l_format.format(l_title.GetPayment()));
//		l_view.setLongClickable(false);
		l_view.setFocusable(false);// ������ListView���ƥ󤣷|�Q�̽�
		return l_view;
    
	}
	public void SetPositiveSymbol(String iv_strPositiveSymbol) {
		this.iv_strPositiveSymbol = iv_strPositiveSymbol;
	}
	public String GetPositiveSymbol() {
		return iv_strPositiveSymbol;
	}
	public void SetNegativeSymbol(String iv_strNegativeSymbol) {
		this.iv_strNegativeSymbol = iv_strNegativeSymbol;
	}
	public String GetNegativeSymbol() {
		return iv_strNegativeSymbol;
	}
	

}
