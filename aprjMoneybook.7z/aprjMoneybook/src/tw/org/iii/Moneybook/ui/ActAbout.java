package tw.org.iii.Moneybook.ui;

import tw.org.iii.Moneybook.R;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class ActAbout extends Activity {

		public static String GLOBAL_MESSAGE="";
		public static String GLOBAL_HYPERLINKTITLE="";
		public static String GLOBAL_URL="";
		public static String GLOBAL_HYPERLINKTITLE2="";
		public static String GLOBAL_URL2="";		
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
        InicialComponent();
    }
    OnClickListener lblLink_Click=new OnClickListener(){
		@Override
		public void onClick(View arg0) {
	        Uri uri = Uri.parse(GLOBAL_URL);
	        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
	        startActivity(intent);
			
		}};
    OnClickListener lblLink2_Click=new OnClickListener(){
			@Override
			public void onClick(View arg0) {
		        Uri uri = Uri.parse(GLOBAL_URL2);
		        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		        startActivity(intent);
				
		}};		
	private void InicialComponent() {
		lblDetail=(TextView)findViewById(R.id.lblAboutDetail);
		lblDetail.setText(ActAbout.GLOBAL_MESSAGE);
		lblLink=(TextView)findViewById(R.id.About_lblHyperLink);
		lblLink.setText(GLOBAL_HYPERLINKTITLE);
		lblLink.setOnClickListener(lblLink_Click);
		lblLink2=(TextView)findViewById(R.id.About_lblHyperLink2);
		lblLink2.setText(GLOBAL_HYPERLINKTITLE2);
		lblLink2.setOnClickListener(lblLink2_Click);		
	}
	TextView lblDetail=null;
	TextView lblLink=null;
	TextView lblLink2=null;
	
}
