package tw.org.iii.Moneybook.ui;

import java.util.ArrayList;
import java.util.List;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CAccount;
import tw.org.iii.Moneybook.lib.da.CItem;
import tw.org.iii.Moneybook.ui.report.ActDailyDetail;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class ActAccountList extends Activity {
	private int iv_intSelectedIndex=-1;
	private CAccount[] iv_accounts=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.accountlist);
		InicialComponent();
		DisplayAccount();
	}
    @Override
	protected void onRestart() {
    	
		super.onRestart();
	}
	private void DisplayAccount() {
    	iv_accounts=CDictionary.CCONTEXT.GetAccountFactory().GetAll();
    	CHomeTitle l_noData=new CHomeTitle();
    	l_noData.SetTitle((String)getResources().getString(R.string.message_nodata));

    	List<CHomeTitle> l_list=new ArrayList<CHomeTitle>();
		
    	if(iv_accounts==null){
    		l_list.add(l_noData);
    	}else{
    		for(int i=0;i<iv_accounts.length;i++){
    			l_noData=new CHomeTitle();
    			l_noData.SetTitle( iv_accounts[i].GetName());
    			l_noData.SetSubTitle( iv_accounts[i].GetType());
    			l_noData.SetIncome(iv_accounts[i].GetMoney() );    	
    			l_list.add(l_noData);	
    		}
    	}    		
		CHomeListAdapter l_adapter=new  CHomeListAdapter(ActAccountList.this,0,l_list);	   
		l_adapter.SetPositiveSymbol("");
		l_adapter.SetNegativeSymbol("");
		lstMenu.setAdapter(l_adapter);
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		DisplayAccount();
		super.onActivityResult(requestCode, resultCode, data);
	}
	OnClickListener btnNew_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Intent l_intent=new Intent(ActAccountList.this,ActAccountEditor.class);					
			startActivityForResult(l_intent,CDictionary.ACTIVEID_ACCOUNTLIST);
		}
    };    
    OnClickListener btnTransfer_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			String l_str="���\��|���}��";
			ActAbout.GLOBAL_MESSAGE=l_str;
			Intent l_intent=new Intent(ActAccountList.this,ActAbout.class);
			startActivity(l_intent);	
		}
    };
    private void ShowItemEditor(CAccount p_account) {
		Bundle l_bundle=new Bundle();
		l_bundle.putInt(CDictionary.BUNDLE_KEY_MENU_TYPE, p_account.GetId());
		Intent l_intent=new Intent(ActAccountList.this,ActAccountEditor.class);	
		l_intent.putExtras(l_bundle);
		startActivityForResult(l_intent,CDictionary.ACTIVEID_ACCOUNTEDITOR);
	}
    OnItemClickListener lstMenu_ItemClick=new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			CAccount l_account=iv_accounts[arg2];
			ShowItemEditor(l_account);
			
		}};
    OnItemLongClickListener lstMenu_LongItemClick=new OnItemLongClickListener() {
		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
				int arg2, long arg3) {
			Builder l_build=new Builder(ActAccountList.this);			
			l_build.setTitle(R.string.title_select_item);
			ListView l_lstView=(ListView)arg0;
			iv_intSelectedIndex=arg2;
			String[] l_strItems=(String[])getResources().getStringArray(R.array.menu_longclick_basicdata_edit_delete);
			l_build.setItems(l_strItems, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					CAccount l_account=iv_accounts[iv_intSelectedIndex];
					if(arg1==0){
						ShowItemEditor(l_account);			
					}else if(arg1==1){
						CDictionary.CCONTEXT.GetAccountFactory().Delete(l_account);
						DisplayAccount();
					}
				}

				});
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();

			return false;
		}
	};
    OnClickListener btnHome_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			finish();
		}
    };    
    
	private void InicialComponent() {
		btnNew=(Button)findViewById(R.id.AccountList_btnNew);
		btnNew.setOnClickListener(btnNew_Click);
		btnHome=(Button)findViewById(R.id.AccountList_btnHome);
		btnHome.setOnClickListener(btnHome_Click);		
		btnTransfer=(Button)findViewById(R.id.AccountList_btnTransfer);
		btnTransfer.setOnClickListener(btnTransfer_Click);	
		lstMenu=(ListView)findViewById(R.id.AccountList_lstMenu);
		lstMenu.setOnItemLongClickListener(lstMenu_LongItemClick);
		lstMenu.setOnItemClickListener(lstMenu_ItemClick);
		lstMenu.setCacheColorHint(0);
	}
	Button btnNew=null;
	Button btnHome=null;
	Button btnTransfer=null;
	ListView lstMenu=null;
}
