package tw.org.iii.Moneybook.ui.report;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CItem;
import tw.org.iii.Moneybook.lib.da.CItemFactory;
import tw.org.iii.Moneybook.lib.da.CItemQueryKey;
import tw.org.iii.Moneybook.lib.util.CDateUtility;
import tw.org.iii.Moneybook.ui.CDictionary;
import tw.org.iii.Moneybook.ui.CHomeListAdapter;
import tw.org.iii.Moneybook.ui.CHomeTitle;
import tw.org.iii.Moneybook.ui.chart.CBarHandler;
import tw.org.iii.Moneybook.ui.chart.CChartItem;
import tw.org.iii.Moneybook.ui.chart.CPieHandler;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActChart extends Activity implements SurfaceHolder.Callback{
	private String iv_strSql="";
	private int iv_intMode=-1;
	private CItem[] iv_items;
	private CItem[] iv_itemProjects;
	private String iv_strCondition="";
	private  CChartItem[] iv_chartitems;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chartstyle01);
		if(getIntent().getExtras()!=null)
			iv_intMode=getIntent().getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);
		CItemQueryKey l_key=new CItemQueryKey();
		l_key.AddDateRange(CDateUtility.GetFirstDateOfMonth(Calendar.getInstance()), 
				CDateUtility.GetLastDateOfMonth(Calendar.getInstance()));
		// �w�]�a�X���몺���
		if(iv_intMode==CDictionary.REPORT_MODE_PROJECT_PAYMENT){			
			l_key.AddPaymentFlag();
			iv_items=CDictionary.CCONTEXT.GetItemFactory().GetByKey(l_key);			
			iv_items=GroupBy(iv_items,iv_intMode);
		}if(iv_intMode==CDictionary.REPORT_MODE_CATALOG_PAYMENT){			
			l_key.AddPaymentFlag();
			iv_items=CDictionary.CCONTEXT.GetItemFactory().GetByKey(l_key);			
			iv_items=GroupBy(iv_items,iv_intMode);
		}
		if(iv_intMode==CDictionary.REPORT_MODE_ACCOUNT_PAYMENT){			
			l_key.AddPaymentFlag();
			iv_items=CDictionary.CCONTEXT.GetItemFactory().GetByKey(l_key);			
			iv_items=GroupBy(iv_items,iv_intMode);
		}		
		InicialComponent();
		DisplayItems();
			
	}
	private CItem[] GroupBy(CItem[] p_items,int p_intMode){
		
		if(p_items==null)
			return p_items;
		Hashtable l_set=new Hashtable();
		for(int i=0;i<p_items.length;i++){
			
			String l_str="";
			if(p_intMode==CDictionary.REPORT_MODE_PROJECT_PAYMENT)
				l_str=p_items[i].GetProject();
			else if(p_intMode==CDictionary.REPORT_MODE_CATALOG_PAYMENT ||
					p_intMode==CDictionary.REPORT_MODE_CATALOG_INCOME )
				l_str=p_items[i].GetCatalog();
			else if(p_intMode==CDictionary.REPORT_MODE_ACCOUNT_INCOME ||
					p_intMode==CDictionary.REPORT_MODE_ACCOUNT_PAYMENT)
				l_str=p_items[i].GetAccountId();
			CItem l_item=(CItem)l_set.get(l_str);
			if(l_item==null){
				l_item=new CItem();
				if(p_intMode==CDictionary.REPORT_MODE_PROJECT_PAYMENT)
					l_item.SetProject(l_str);
				else if(p_intMode==CDictionary.REPORT_MODE_CATALOG_PAYMENT ||
						p_intMode==CDictionary.REPORT_MODE_CATALOG_INCOME )
					l_item.SetCatalog(l_str);
				else if(p_intMode==CDictionary.REPORT_MODE_ACCOUNT_INCOME ||
						p_intMode==CDictionary.REPORT_MODE_ACCOUNT_PAYMENT)
					l_item.SetAccount(l_str);				
				l_set.put(l_str, l_item);
			}
			l_item.SetMoney(l_item.GetMoney()+p_items[i].GetMoney());			
		}
		CItem[] l_items=new CItem[l_set.size()];
		Iterator l_iteartor=l_set.values().iterator();
		int l_intCount=0;
		while(l_iteartor.hasNext()){
			l_items[l_intCount]=(CItem)l_iteartor.next();			
			l_intCount++;
		}
		//SortByDate(l_items,CDictionary.SORT_BIGENDING);
		return l_items;

	}
	private boolean IsNumberExisted(int p_intTemp, int[] p_intNOs) {
		for(int i=0;i<p_intNOs.length;i++){
			if(p_intTemp==p_intNOs[i])
				return true;
		}
		return false;
	}
	
	private int GetColor() {  
        return Color.rgb(  
        		GetRandomColors(1,0,255)[0],  
        		GetRandomColors(1,0,255)[0],  
        		GetRandomColors(1,0,255)[0]);  
    } 
	private int[] GetRandomColors(int p_intCount,int p_intMin,int p_intMax){
		
			DecimalFormat l_format=new DecimalFormat("0");
			int[] l_intNOs=new int[p_intCount];
			int l_intTemp=0;
			int l_intCount=0;
			while(l_intCount<p_intCount){
				l_intTemp=Integer.parseInt(l_format.format(1000*Math.random()));
				
				if(l_intTemp>=p_intMin && l_intTemp<=p_intMax){
					if(!IsNumberExisted(l_intTemp,l_intNOs)){
						
						l_intNOs[l_intCount]=l_intTemp;
						l_intCount++;
					}
				}									
			}
			return l_intNOs;			
	}
	
	private CChartItem[] ToChartItem(CItem[] p_items,int p_intColor){
		iv_chartitems=new CChartItem[p_items.length];
		//int[] l_intColors=GetRandomColors(p_items.length,0,65535);
		for(int i=0;i<p_items.length;i++){
			iv_chartitems[i]=new CChartItem();
			//l_items[i].SetColor(l_intColors[i]);
			iv_chartitems[i].SetColor(GetColor());
			
			if(iv_intMode==CDictionary.REPORT_MODE_CATALOG_PAYMENT ||
					iv_intMode==CDictionary.REPORT_MODE_CATALOG_INCOME )
				iv_chartitems[i].SetTitle(p_items[i].GetCatalog());
			if(iv_intMode==CDictionary.REPORT_MODE_PROJECT_INCOME ||
					iv_intMode==CDictionary.REPORT_MODE_PROJECT_PAYMENT )
				iv_chartitems[i].SetTitle(p_items[i].GetProject());
			if(iv_intMode==CDictionary.REPORT_MODE_ACCOUNT_INCOME||
					iv_intMode==CDictionary.REPORT_MODE_ACCOUNT_PAYMENT)
				iv_chartitems[i].SetTitle(CDictionary.CCONTEXT.GetAccountFactory().GetNameById( p_items[i].GetAccountId()));
			
			if(p_items[i].GetMoney()<0)
				iv_chartitems[i].SetData(-p_items[i].GetMoney());
			else
				iv_chartitems[i].SetData(p_items[i].GetMoney());
		}
		return iv_chartitems;
	}
	
	private void DisplayItems(){
		if(iv_items==null){
			//lblResult.setText((String)getResources().getString(R.string.message_nodata));
    		List<CHomeTitle> l_list=new ArrayList<CHomeTitle>();				
    		CHomeListAdapter l_adapter=new  CHomeListAdapter(ActChart.this,0,l_list);		
    		lstDetail.setAdapter(l_adapter);
			return;
		}
		double l_dblPay=0,l_dblIn=0;
    	if(iv_items!=null){
    		CHomeTitle[] l_todays=new CHomeTitle[iv_items.length];    	        	
    		for(int i=0;i<iv_items.length;i++){
    			l_todays[i]=new CHomeTitle();
    			if(iv_intMode==CDictionary.REPORT_MODE_MONTH){
    				l_todays[i].SetTitle(CDateUtility.GetFormatedDate( iv_items[i].GetDate()));        			
    			}else if(iv_intMode==CDictionary.REPORT_MODE_CATALOG_PAYMENT){
    				if("".equals(iv_items[i].GetCatalog().trim()))
    					l_todays[i].SetTitle((i+1)+")������");
    				else
    					l_todays[i].SetTitle(String.valueOf(i+1)+")"+iv_items[i].GetCatalog());
    			}else if(iv_intMode==CDictionary.REPORT_MODE_PROJECT_PAYMENT){
    				if("".equals(iv_items[i].GetProject().trim()))
    					l_todays[i].SetTitle((i+1)+")������");
    				else
    					l_todays[i].SetTitle((i+1)+")"+iv_items[i].GetProject());    				
    			}else if(iv_intMode==CDictionary.REPORT_MODE_ACCOUNT_PAYMENT){
    				if("".equals(iv_items[i].GetAccountId().trim()))
    					l_todays[i].SetTitle((i+1)+")������");
    				else{
    					l_todays[i].SetTitle((i+1)+")"+CDictionary.CCONTEXT.GetAccountFactory()
    							.GetNameById(iv_items[i].GetAccountId()));
    				}
    			}
    			
    			else{
    				l_todays[i].SetTitle("("+(i+1)+")"+iv_items[i].GetCatalog());
//        			l_todays[i].SetSubTitle(CDateUtility.GetFormatedDate( iv_items[i].GetDate())+" / "+
//        					iv_items[i].GetCatalogSub());
    			}
    			
    					
    			if(iv_items[i].GetMoney()<0){
    				l_todays[i].SetPayment(iv_items[i].GetMoney());    				
    				l_dblPay+=iv_items[i].GetMoney();
				}	else{
					l_todays[i].SetIncome(iv_items[i].GetMoney());
					l_dblIn+=iv_items[i].GetMoney();
    			}
			}
    		
    		List<CHomeTitle> l_list=new ArrayList<CHomeTitle>();				
    		for(int i=0;i<l_todays.length;i++){
    			l_list.add(l_todays[i]);	
    		}
    		
    		CHomeListAdapter l_adapter=new  CHomeListAdapter(ActChart.this,0,l_list);		
    		lstDetail.setAdapter(l_adapter);
    	}
	}
	
	private CPieHandler GetPieHandler (){
		CPieHandler l_barHandle=new CPieHandler();
		l_barHandle.SetCanvasColor(CDictionary.CCONTEXT.GetConfig().GetColorHomeButton1());
		l_barHandle.SetChartBackgroundColor1(CDictionary.CCONTEXT.GetConfig().GetChartBackgroundColor1());
		l_barHandle.SetChartBackgroundColor2(CDictionary.CCONTEXT.GetConfig().GetChartBackgroundColor2());
		l_barHandle.SetFrontColor(Color.BLUE);
		l_barHandle.SetLineColor(CDictionary.CCONTEXT.GetConfig().GetChartLineColor2());
		l_barHandle.SetIntervalLength(10);
		l_barHandle.SetMargin(75);
		return l_barHandle;
	}
	
	private CBarHandler GetChartHandler (){
		CBarHandler l_barHandle=new CBarHandler();
		l_barHandle.SetCanvasColor(CDictionary.CCONTEXT.GetConfig().GetColorHomeButton1());
		l_barHandle.SetChartBackgroundColor1(CDictionary.CCONTEXT.GetConfig().GetChartBackgroundColor1());
		l_barHandle.SetChartBackgroundColor2(CDictionary.CCONTEXT.GetConfig().GetChartBackgroundColor2());
		l_barHandle.SetFrontColor(Color.BLUE);
		l_barHandle.SetChartBarColor(CDictionary.CCONTEXT.GetConfig().GetChartBarColor());
		l_barHandle.SetLineColor(CDictionary.CCONTEXT.GetConfig().GetChartLineColor2());
		l_barHandle.SetIntervalLength(10);
		l_barHandle.SetMargin(50);
		return l_barHandle;
	}
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		if(iv_items==null)
			return;
		Canvas l_canvas=GetChartHandler().Draw(holder.lockCanvas(), ToChartItem(iv_items,
				CDictionary.CCONTEXT.GetConfig().GetChartBarColor()));
		holder.unlockCanvasAndPost(l_canvas);
		
//		Paint l_paint=new Paint();		
//		Canvas canvas=holder.lockCanvas();		
//		l_paint.setColor(Color.YELLOW);
//		l_paint.setAntiAlias(true);
//		
//		if(canvas!=null){
//			canvas.drawColor(Color.RED);
//			l_paint.setTextSize(52);
//			canvas.drawText("Comming Soon", 20, 50, l_paint);
//			l_paint.setColor(Color.GREEN);
//			canvas.drawArc(new RectF(40, 10, 400, 370), 135, 60, true, l_paint);
//			
//			holder.unlockCanvasAndPost(canvas);
//		}
	}
	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode==CDictionary.ACTIVEID_QUERYCONDITION){
			if(data==null)
				return;
			if(data.getExtras()!=null){
				iv_strSql=data.getExtras().getString(CDictionary.BUNDLE_KEY_MENU_TYPE);
				String l_str=data.getExtras().getString(CItemFactory.FIELD_DATE);
				iv_strCondition="";				
				if(l_str!=null)
					iv_strCondition+=l_str+"\r\n";
				l_str=data.getExtras().getString(CItemFactory.FIELD_ACCOUNT);		
				if(l_str!=null)
					iv_strCondition+=l_str+" ";				
				l_str=data.getExtras().getString(CItemFactory.FIELD_PROJECT);		
				if(l_str!=null)
					iv_strCondition+=l_str+" ";
				l_str=data.getExtras().getString(CItemFactory.FIELD_CATALOG);				
				if(l_str!=null)
					iv_strCondition+=l_str+" ";
				iv_items=CDictionary.CCONTEXT.GetItemFactory().GetBySql(iv_strSql);
				if(iv_intMode==CDictionary.REPORT_MODE_ACCOUNT_PAYMENT ||
					iv_intMode==CDictionary.REPORT_MODE_PROJECT_PAYMENT ||
					iv_intMode==CDictionary.REPORT_MODE_CATALOG_PAYMENT 
						)
					iv_items=ItemFilter(iv_items,CDictionary.ITEMEDITOR_MODE_PAYMENT);
				else
					iv_items=ItemFilter(iv_items,CDictionary.ITEMEDITOR_MODE_INCOME);
				iv_items=GroupBy(iv_items, iv_intMode);
				DisplayItems();
				lblTitle.setText(iv_strCondition);
			}
		}		
	}
	
	private CItem[] ItemFilter(CItem[] p_items,int p_mode){
		if(p_items==null)
			return p_items;
		ArrayList<CItem> l_list=new ArrayList<CItem>();
		for(int i=0;i<p_items.length;i++){
			if(p_mode==CDictionary.ITEMEDITOR_MODE_INCOME && p_items[i].GetMoney()>0){
				l_list.add(p_items[i]);
			}else if(p_mode==CDictionary.ITEMEDITOR_MODE_PAYMENT && p_items[i].GetMoney()<0){
				l_list.add(p_items[i]);
			}
		}
		return (CItem[])l_list.toArray(new CItem[l_list.size()]);
	}
	
	OnClickListener btnSearch_Click =new OnClickListener(){
		public void onClick(View arg0) {		
			
			Intent l_intent=new Intent(ActChart.this,ActQueryCondition.class);
			startActivityForResult(l_intent,CDictionary.ACTIVEID_QUERYCONDITION);
			
	}};	
	OnClickListener btnPie_Click =new OnClickListener(){
		public void onClick(View arg0) {		
			
			if(iv_items==null)
				return;
			if(iv_chartitems==null)
				iv_chartitems=ToChartItem(iv_items,	CDictionary.CCONTEXT.GetConfig().GetChartBarColor());
			Canvas l_canvas=GetPieHandler().Draw(sfvChart.getHolder().lockCanvas(), iv_chartitems);
			sfvChart.getHolder().unlockCanvasAndPost(l_canvas);
			
	}};	
	OnClickListener btnBar_Click =new OnClickListener(){
		public void onClick(View arg0) {		
			
			if(iv_items==null)
				return;
			if(iv_chartitems==null)
				iv_chartitems=ToChartItem(iv_items,	CDictionary.CCONTEXT.GetConfig().GetChartBarColor());
			Canvas l_canvas=GetChartHandler().Draw(sfvChart.getHolder().lockCanvas(), iv_chartitems);
			sfvChart.getHolder().unlockCanvasAndPost(l_canvas);
			
	}};
	private void InicialComponent() {
		sfvChart=(SurfaceView)findViewById(R.id.ChartStyle01_img);
		lstDetail=(ListView)findViewById(R.id.ChartStyle01_lstMenu);;
		lstDetail.setCacheColorHint(0);
		sfvChart.getHolder().addCallback(this);	
		btnSearch=(ImageButton)findViewById(R.id.ChartStyle01_btnSearch);
		btnSearch.setOnClickListener(btnSearch_Click);
		btnPie=(ImageButton)findViewById(R.id.ChartStyle01_btnPie);
		btnPie.setOnClickListener(btnPie_Click);
		btnBar=(ImageButton)findViewById(R.id.ChartStyle01_btnBar);
		btnBar.setOnClickListener(btnBar_Click);		
		lblTitle=(TextView)findViewById(R.id.ChartStyle01_lblTitle);
	}
	SurfaceView  sfvChart=null;
	ListView  lstDetail=null;
	ImageButton btnSearch=null;
	ImageButton btnPie=null;
	ImageButton btnBar=null;
	TextView lblTitle=null;
}
