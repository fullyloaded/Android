package tw.org.iii.Moneybook.ui;

public class CDictionary {

	public final static int SORT_BIGENDING=1;
	public final static int SORT_LITLEENDING=2;
	public final static int ACTIVEID_INCOME=1001;
	public final static int ACTIVEID_PAYMENT=1002;
	public final static int ACTIVEID_REPORT=1003;
	public final static int ACTIVEID_BASICDATA=1004;
	public final static int ACTIVEID_MENU=1005;
	public final static int ACTIVEID_ACCOUNTLIST=1006;
	
	public final static int ACTIVEID_CODEEDITOR=1007;
	public final static int ACTIVEID_DAILYDETAIL=1008;
	public final static int ACTIVEID_ACCOUNTEDITOR=1009;
	public final static int ACTIVEID_QUERYCONDITION=1010;
	public final static int ACTIVEID_REPORT_DETAIL=1011;
	public final static int ACTIVEID_REPORT_DATESTATIC=1012;
	public final static int ACTIVEID_CALCULATORINPUT=1105;
	public final static int ITEMEDITOR_MODE_PAYMENT=1;
	public final static int ITEMEDITOR_MODE_INCOME=2;
	
	public final static String EDITOR_TYPE_DEFAULT="EDITOR_TYPE_DEFAULT";
	public final static String EDITOR_TYPE_CATALOG_PAYMENT="EDITOR_TYPE_CATALOG_PAYMENT";
	public final static String EDITOR_TYPE_CATALOG_INCOME="EDITOR_TYPE_CATALOG_INCOME";
	public final static String EDITOR_TYPE_PROJECT="EDITOR_TYPE_PROJECT";
	public final static String EDITOR_TYPE_CATALOGSUB_PAYMENT="EDITOR_TYPE_CATALOGSUB_PAYMENT";
	public final static String EDITOR_TYPE_CATALOGSUB_INCOME="EDITOR_TYPE_CATALOGSUB_INCOME";
	public final static String DEBUG_TAG="Moneybook_debug";
	
	public  final static int REPORT_MODE_DAILY=100;
	public  final static int REPORT_MODE_MONTH=101;
	
	public  final static int REPORT_MODE_PROJECT_INCOME=201;
	public  final static int REPORT_MODE_PROJECT_PAYMENT=202;
	public  final static int REPORT_MODE_ACCOUNT_PAYMENT=203;
	public  final static int REPORT_MODE_ACCOUNT_INCOME=204;
	public  final static int REPORT_MODE_CATALOG_INCOME=205;
	public  final static int REPORT_MODE_CATALOG_PAYMENT=206;
	public  final static int REPORT_MODE_CATALOGSUB_PAYMENT=207;
	public  final static int REPORT_MODE_CATALOGSUB_INCOME=208;
	
	public final static String BUNDLE_KEY_MENU_TYPE="BUNDLE_KEY_MENU_TYPE";
	public final static String BUNDLE_KEY_DATE="BUNDLE_KEY_DATE";
	public final static String KEY_DEFAULTCODE_ISEXECUTED="KEY_DEFAULTCODE_ISEXECUTED";
	public static CContext CCONTEXT=null;
	

}


