package tw.org.iii.Moneybook.ui.chart;

import java.text.DecimalFormat;

import tw.org.iii.Moneybook.ui.CDictionary;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.Log;

public class CPieHandler {
	private Canvas iv_canvas;
	private int iv_intCanvasColor=0;
	private int iv_intFrontColor=0;
	private int iv_intMargin=0;
	private int iv_intIntervalLength=0;
	private int iv_intChartBackgroundColor1=0;
	private int iv_intChartBackgroundColor2=0;
	private int iv_intLineColor=0;
	private boolean iv_blnIsShowLine;
		
	public Canvas Draw(Canvas p_canvas,CChartItem[] p_items){
		iv_canvas=p_canvas;
		p_canvas.drawColor(iv_intCanvasColor);		
		double l_dblSum=0;
		for(int i=0;i<p_items.length;i++){// ���
			l_dblSum+=p_items[i].GetData();			
		}
		float l_fltCanvasBorder=p_canvas.getHeight();
		if(p_canvas.getWidth()<p_canvas.getHeight())
			l_fltCanvasBorder=p_canvas.getWidth();
			
			
		
		RectF l_rec=new RectF(iv_intMargin, iv_intMargin, l_fltCanvasBorder-iv_intMargin, l_fltCanvasBorder-iv_intMargin);
		Paint l_paint=new Paint(3);
		l_paint.setAntiAlias(true);
		
		float l_fltRanStart=0;
		float l_fltRanData=0;
		l_fltCanvasBorder=l_fltCanvasBorder-iv_intMargin*2;
	//	float l_fltDiameterY=l_fltCanvasBorder-iv_intMargin*2;
		
		float l_porinX=iv_intMargin+l_fltCanvasBorder/2;
		float l_porinY=iv_intMargin+l_fltCanvasBorder/2;
		//		Draw pie content.
		for(int i=0;i<p_items.length;i++){// ���
			l_paint.setColor(p_items[i].GetColor());
			l_fltRanData=(float)(360*(p_items[i].GetData()/l_dblSum));	
			p_canvas.drawArc(l_rec,l_fltRanStart,l_fltRanData, true, l_paint);		
			l_fltRanStart+=l_fltRanData;
		}
		
		l_paint.setTextSize(16);
		l_paint.setColor(iv_intFrontColor);	
		l_fltRanStart=0;
		
		
		
		for(int i=0;i<p_items.length;i++){// ���			
				l_fltRanData=(float)(360*(p_items[i].GetData()/l_dblSum));									
				l_fltRanStart+=l_fltRanData;			
				float l_fltTextX=0;
				float l_fltTextY=0;
				float l_fltTextX2=0;
				float l_fltTextY2=0;				
				
				float l_fltTempRang=l_fltRanStart-(l_fltRanData/2);
				if(l_fltTempRang>180)
					l_fltTempRang=360-l_fltTempRang;
				
				l_fltTextX=iv_intMargin+l_fltCanvasBorder*(1-l_fltTempRang/180);
				
				 l_fltTempRang=l_fltRanStart-(l_fltRanData/2);
				 Log.d(CDictionary.DEBUG_TAG,p_items[i].GetTitle()+":"+String.valueOf(l_fltTempRang));
					if(l_fltTempRang<=90)
						l_fltTempRang+=90;
					else if(l_fltTempRang<=180)
						l_fltTempRang=90+(180-l_fltTempRang);
					else if(l_fltTempRang<=270)
						l_fltTempRang=270-l_fltTempRang;
					else
						l_fltTempRang=l_fltTempRang-270;
					

				l_fltTextY=iv_intMargin+( l_fltCanvasBorder)*(l_fltTempRang/180);
				float l_fltLine=iv_intMargin;
				float l_fltTextLeft=l_fltTextX;
				l_fltTextX2=l_fltTextX;
				l_fltTextY2=l_fltTextY;
				if(l_fltTextX>l_porinX){
					l_fltTextX2+=l_fltLine/4;
					l_fltTextLeft=l_fltTextX2;
				}else{					
					l_fltTextX2-=l_fltLine*2/3;
					l_fltTextLeft-=l_fltLine;
				}
				if(l_fltTextY>l_porinY)
					l_fltTextY2+=(l_fltLine+35)/2;
				else					
					l_fltTextY2-=(l_fltLine+35)/2;
//				Log.d(CDictionary.DEBUG_TAG,"���I:X"+String.valueOf(l_porinX));
//				Log.d(CDictionary.DEBUG_TAG,"���I:Y"+String.valueOf(l_porinY));
//				Log.d(CDictionary.DEBUG_TAG,"���I:XX"+String.valueOf(l_fltTextX));
				
				DecimalFormat l_format=new DecimalFormat("0"); 
				l_paint.setAntiAlias(true);
				p_canvas.drawLine(l_fltTextX, l_fltTextY, l_fltTextX2, l_fltTextY2, l_paint);
				p_canvas.drawText(p_items[i].GetTitle()+"("+
						l_format.format((p_items[i].GetData()*100)/l_dblSum)+
						"%)" ,l_fltTextLeft+5, l_fltTextY2+5, l_paint);				
		}			
		return p_canvas;
	}

	public void SetCanvasColor(int iv_intCanvasColor) {
		this.iv_intCanvasColor = iv_intCanvasColor;
	}

	public int GetCanvasColor() {
		return iv_intCanvasColor;
	}

	public void SetFrontColor(int iv_intFrontCanvasColor) {
		this.iv_intFrontColor = iv_intFrontCanvasColor;
	}

	public int GetFrontColor() {
		return iv_intFrontColor;
	}

	public void SetMargin(int iv_intMargin) {
		this.iv_intMargin = iv_intMargin;
	}

	public int GetMargin() {
		return iv_intMargin;
	}

	public void SetIntervalLength(int iv_intIntervalLength) {
		this.iv_intIntervalLength = iv_intIntervalLength;
	}

	public int GetIntervalLength() {
		return iv_intIntervalLength;
	}

	public void SetChartBackgroundColor1(int iv_intChartBackgroundColor1) {
		this.iv_intChartBackgroundColor1 = iv_intChartBackgroundColor1;
	}

	public int GetChartBackgroundColor1() {
		return iv_intChartBackgroundColor1;
	}

	public void SetChartBackgroundColor2(int iv_intChartBackgroundColor2) {
		this.iv_intChartBackgroundColor2 = iv_intChartBackgroundColor2;
	}

	public int GetChartBackgroundColor2() {
		return iv_intChartBackgroundColor2;
	}

	public void SetLineColor(int iv_intLineColor) {
		this.iv_intLineColor = iv_intLineColor;
	}

	public int GetLineColor() {
		return iv_intLineColor;
	}

	public void SetIsShowLine(boolean iv_blnIsShowLine) {
		this.iv_blnIsShowLine = iv_blnIsShowLine;
	}

	public boolean GetIsShowLine() {
		return iv_blnIsShowLine;
	}

}
