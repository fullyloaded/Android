package tw.org.iii.Moneybook.ui;

import java.text.DecimalFormat;
import java.util.Calendar;

import tw.org.iii.Moneybook.R;
import tw.org.iii.Moneybook.lib.da.CAccount;
import tw.org.iii.Moneybook.lib.da.CCode;
import tw.org.iii.Moneybook.lib.da.CItem;
import tw.org.iii.Moneybook.lib.da.CItemFactory;
import tw.org.iii.Moneybook.lib.util.CDateUtility;
import tw.org.iii.Moneybook.ui.common.ActCalculatorInput;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class ActItemEditor extends Activity {
	
	public static int EDITOR_MODE=0;
	private String iv_intFocusField="";
	private CItem iv_item;
	private CCode[] iv_catalogs;
	private CCode[] iv_catalogSubs;
	private String[] iv_strProjects;
	private CAccount[] iv_accounts;
	private CAccount iv_accountSelected=null;
	private CItem GetItem(){
		if (iv_item==null)
			iv_item=CDictionary.CCONTEXT.GetItemFactory().Create();
		return iv_item;
	}
	
	private boolean IsUiValidated() {
		String l_str="";
		if("".equals(btnMoney.getText().toString()))
			l_str+="\r\n��������J���B";
		if("".equals(txtDate.getText().toString()))
			l_str+="\r\n��������J���";
		if(txtDate.getText().toString().length()!=10)
			l_str+="\r\n����J������榡���~�A�����OYYYY-MM-DD";
		if(!"".equals(l_str))
			CDictionary.CCONTEXT.ShowMessage(this,l_str,"�������");
			
			return "".equals(l_str);
	}
	
	private CItem GetFilled(CItem p_item){
		if (EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_INCOME)
			p_item.SetMoney(Double.parseDouble(btnMoney.getText().toString()));
		else
			p_item.SetMoney(-Double.parseDouble(btnMoney.getText().toString()));
		
		p_item.SetDate(txtDate.getText().toString().replace("-","")+
				CDateUtility.ToTimeDbString(Calendar.getInstance()));
		p_item.SetCatalog(btnCatalog.getText().toString());
		p_item.SetCatalogSub(btnCatalogSub.getText().toString());
		p_item.SetProject(btnProject.getText().toString());
		p_item.SetMemo(txtMemo.getText().toString());
		p_item.SetReceptNO(btnRecept.getText().toString());
		if(iv_accountSelected!=null)
			p_item.SetAccount(String.valueOf(iv_accountSelected.GetId()));	
		return p_item;
	}
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.itemeditor);
        InicialComponent();
        iv_accounts=CDictionary.CCONTEXT.GetAccountFactory().GetAll();
        if(iv_accounts!=null){
        	iv_accountSelected=iv_accounts[0];
        	btnAccount.setText(iv_accountSelected.GetName());
        }        
        if(getIntent().getExtras()!=null){
        	int l_int=getIntent().getExtras().getInt(CDictionary.BUNDLE_KEY_MENU_TYPE);        	
        	iv_item=CDictionary.CCONTEXT.GetItemFactory().GetById(l_int);        	
        	if(iv_item!=null){        	
        		EDITOR_MODE=CDictionary.ITEMEDITOR_MODE_INCOME;
        		if(iv_item.GetMoney()<0)
        			EDITOR_MODE=CDictionary.ITEMEDITOR_MODE_PAYMENT;
        		DisplayItem(iv_item);
        	}
        }
        if (EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_PAYMENT){
        	lblTitle.setText((String)getResources().getString(R.string.itemeditor_title_payment));
        }else{
        	lblTitle.setText((String)getResources().getString(R.string.itemeditor_title_income));
        	
        }
        
        
    }
    
    private CAccount  GetAccountById(int p_intId){
    	
		if(iv_accounts!=null){
			for(int i=0 ;i<iv_accounts.length;i++){
				if(iv_accounts[i].GetId()==p_intId)
					return iv_accounts[i];
			}
		}
    	return null;
    }
    
    private void DisplayItem(CItem p_item) {
		if(p_item==null)
			return;
		iv_accountSelected=GetAccountById(Integer.parseInt(p_item.GetAccountId()));
		Log.d(CDictionary.DEBUG_TAG, "��b��");
		if(iv_accountSelected!=null)
			btnAccount.setText(iv_accountSelected.GetName());	
		btnCatalog.setText(p_item.GetCatalog());
		btnCatalogSub.setText(p_item.GetCatalogSub());
		txtDate.setText( CDateUtility.GetFormatedDate(p_item.GetDate()));
		txtMemo.setText(p_item.GetMemo());
		btnProject.setText(p_item.GetProject());
		btnRecept.setText(p_item.GetReceptNO());
		DecimalFormat l_format=new DecimalFormat("0");
		if(p_item.GetMoney()<0){
			EDITOR_MODE=CDictionary.ITEMEDITOR_MODE_PAYMENT;
			btnMoney.setText(l_format.format((-p_item.GetMoney())));
		}else{
			EDITOR_MODE=CDictionary.ITEMEDITOR_MODE_INCOME;
			btnMoney.setText(l_format.format((p_item.GetMoney())));
		}
		iv_catalogSubs=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(
				p_item.GetCatalog());
		
		
	}
	OnClickListener btnOk_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			if(IsUiValidated()){				
				CDictionary.CCONTEXT.GetItemFactory().Update(GetFilled(GetItem()));
				if(iv_accountSelected!=null){
					double l_dbl=Double.parseDouble(btnMoney.getText().toString());
					if (EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_PAYMENT)					
						l_dbl*=-1;		
					iv_accountSelected.AddMoney(l_dbl);
					CDictionary.CCONTEXT.GetAccountFactory().Update(iv_accountSelected);
				}
				finish();								
				Toast.makeText(ActItemEditor.this,R.string.message_save_successfull,Toast.LENGTH_SHORT).show();
			}
		}   	
    };      		 
    OnClickListener btnCancel_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			
			finish();
		}    	
    };        
    OnClickListener btnClearMoney_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			
			btnMoney.setText("");
		}    	
    };  
    	    
    @Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		try{
			if(requestCode==CDictionary.ACTIVEID_MENU){
				ResetCodeItem();
				Log.d("Moneybook_Debug","��s��project"+iv_intFocusField);
				
					
				if(data.getExtras()!=null){
					String l_str=data.getExtras().getString(CDictionary.BUNDLE_KEY_MENU_TYPE);						
					if(!"".equals(l_str)){
						if( CItemFactory.FIELD_PROJECT.equals(iv_intFocusField)){
							btnProject.setText(l_str);
						}
						else if( CItemFactory.FIELD_CATALOG.equals(iv_intFocusField)){
							btnCatalog.setText(l_str);
						}
						else if( CItemFactory.FIELD_CATALOGSUB.equals(iv_intFocusField)){
							btnCatalogSub.setText(l_str);
						}
					}
				}
			}
			if(requestCode==CDictionary.ACTIVEID_CALCULATORINPUT){
				
				if( CItemFactory.FIELD_RECEPT.equals(iv_intFocusField)){										
					btnRecept.setText(data.getExtras().getString(CDictionary.BUNDLE_KEY_MENU_TYPE));
				}else if( CItemFactory.FIELD_MONEY.equals(iv_intFocusField)){
					double l_dbl=data.getExtras().getDouble(CDictionary.BUNDLE_KEY_MENU_TYPE);
					DecimalFormat l_format = new DecimalFormat("0");
					btnMoney.setText(l_format.format(l_dbl));
				}
			}
		}catch(Exception ex){
			
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	OnClickListener btnCatalogSub_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			iv_intFocusField=CItemFactory.FIELD_CATALOGSUB;
			Builder l_build=new Builder(ActItemEditor.this);			
			l_build.setTitle(R.string.title_select_item);
			
			String[] l_strCatalogs=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
			
			if(iv_catalogSubs!=null){
				String l_str=l_strCatalogs[0];
				l_strCatalogs=new String[iv_catalogSubs.length+1];
				l_strCatalogs[0]=l_str;
				for(int i=0;i<iv_catalogSubs.length;i++){
					l_strCatalogs[i+1]=iv_catalogSubs[i].GetValue();
				}			
			}
			l_build.setItems(l_strCatalogs, new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {
						if(which==0){
							if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_INCOME){
								ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_INCOME;					
							}else{
								ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_PAYMENT;				
							}
							Intent l_intent=new Intent(ActItemEditor.this,ActCodeEditor.class);					
							startActivityForResult(l_intent,CDictionary.ACTIVEID_MENU);									
						}else{							
							btnCatalogSub.setText(iv_catalogSubs[which-1].GetValue());
						}						
					}
				}	
			);
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
		}    	
    };  
    
	OnClickListener btnCatalog_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			iv_intFocusField=CItemFactory.FIELD_CATALOG;
			Builder l_build=new Builder(ActItemEditor.this);			
			l_build.setTitle(R.string.title_select_item);
			
			String[] l_strCatalogs=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
			
			if(iv_catalogs!=null){
				String l_str=l_strCatalogs[0];
				l_strCatalogs=new String[iv_catalogs.length+1];
				l_strCatalogs[0]=l_str;
				for(int i=0;i<iv_catalogs.length;i++){
					l_strCatalogs[i+1]=iv_catalogs[i].GetValue();
				}			
			}
	
			l_build.setItems(l_strCatalogs, new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {
						if(which==0){
							if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_INCOME){
								ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_INCOME;					
							}else{
								ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_CATALOG_PAYMENT;				
							}
							Intent l_intent=new Intent(ActItemEditor.this,ActCodeEditor.class);					
							startActivityForResult(l_intent,CDictionary.ACTIVEID_MENU);									
						}else{							
							btnCatalog.setText(iv_catalogs[which-1].GetValue());
							iv_catalogSubs=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(
									String.valueOf(iv_catalogs[which-1].GetId()));
							if(iv_catalogSubs!=null)
								btnCatalogSub.setText(iv_catalogSubs[0].GetValue());
						}						
					}
				}	
			);
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
		}    	
    };  
	OnClickListener btnProject_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			iv_intFocusField=CItemFactory.FIELD_PROJECT;
			Builder l_build=new Builder(ActItemEditor.this);			
			l_build.setTitle(R.string.title_select_item);
			l_build.setItems(iv_strProjects, new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {
						if(which==0){							
							ActCodeEditor.EDITOR_TYPE=CDictionary.EDITOR_TYPE_PROJECT;				
							Intent l_intent=new Intent(ActItemEditor.this,ActCodeEditor.class);					
							startActivityForResult(l_intent,CDictionary.ACTIVEID_MENU);									
						}else{							
							btnProject.setText(iv_strProjects[which]);
						}						
					}
				}	
			);
			
			Dialog l_dialog=l_build.create();
			l_dialog.show();
		}    	
    };  
    
    OnClickListener btnDate_Click =new OnClickListener(){
		@Override		
		public void onClick(View arg0) {
			Calendar l_calendar=Calendar.getInstance();
			
			Dialog l_dialog=new DatePickerDialog( ActItemEditor.this,
				new DatePickerDialog.OnDateSetListener()
				{								
					public void onDateSet(DatePicker arg0, int arg1,	int arg2, int arg3) 
					{
						DecimalFormat l_format=new DecimalFormat("00");
						txtDate.setText(String.valueOf(arg1)+"-"+
								l_format.format(arg2+1)+"-"+
								l_format.format(arg3));
					}				
				},
				l_calendar.get(Calendar.YEAR),
				l_calendar.get(Calendar.MONTH),
				l_calendar.get(Calendar.DATE)
			);
			l_dialog.show();
		}
    };
    

	private void ResetCodeItem() {
		// reset catalog items
		String[] l_strCatalogs=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
		
		if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_INCOME){
			iv_catalogs=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_CATALOG_INCOME);			
		}else {
			iv_catalogs=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT);
		}
		
		if(iv_catalogs!=null){
			String l_str=iv_catalogs[0].GetValue();
			l_strCatalogs=new String[iv_catalogs.length+1];
			l_strCatalogs[0]=l_str;
			for(int i=0;i<iv_catalogs.length;i++){
				l_strCatalogs[i+1]=iv_catalogs[i].GetValue();
			}			
		}
		// reset project  items
		iv_strProjects=new String[]{(String)getResources().getText(R.string.message_click_to_addnew)};
		CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_PROJECT);
		if(l_codes!=null){
			String l_str=iv_strProjects[0];
			iv_strProjects=new String[l_codes.length+1];
			iv_strProjects[0]=l_str;
			for(int i=0;i<l_codes.length;i++){
				iv_strProjects[i+1]=l_codes[i].GetValue();
			}			
		}
		
		
	}
		OnClickListener btnProjectClear_Click =new OnClickListener(){
		@Override
		public void onClick(View v) {
			btnProject.setText("");
		}};	
	OnClickListener btnMoney_Click =new OnClickListener(){
		@Override
		public void onClick(View v) {
			iv_intFocusField=CItemFactory.FIELD_MONEY;
			ActCalculatorInput.INPUT_TYPE=ActCalculatorInput.INPUT_TYPE_DOUBLE;
			Bundle l_bundle=new Bundle();
			double l_dblMoney=0;
			if(!"".equals(btnMoney.getText().toString()))
				l_dblMoney= Double.parseDouble(btnMoney.getText().toString());
			l_bundle.putDouble(CDictionary.BUNDLE_KEY_MENU_TYPE, l_dblMoney);
			Intent l_intent=new Intent(ActItemEditor.this,ActCalculatorInput.class);
			l_intent.putExtras(l_bundle);
			startActivityForResult(l_intent, CDictionary.ACTIVEID_CALCULATORINPUT);
			
		}};	
		OnClickListener btnAccount_Click =new OnClickListener(){
			public void onClick(View arg0) {			
				Builder l_build=new AlertDialog.Builder(ActItemEditor.this);
				if(iv_accounts==null)
					return;
				String[] l_strTitles=new String[iv_accounts.length];
				for(int i=0;i<l_strTitles.length;i++)
					l_strTitles[i]=iv_accounts[i].GetName()+"("+String.valueOf(iv_accounts[i].GetMoney())+")";
				l_build.setTitle(R.string.title_select_item);
				l_build.setItems(l_strTitles,new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialog, int which) {
						iv_accountSelected=iv_accounts[which];
						btnAccount.setText(iv_accountSelected.GetName());					
					}});
						
				
				Dialog l_dialog=l_build.create();
				l_dialog.show();
			}};
	OnClickListener btnClearRecept_Click =new OnClickListener(){
		public void onClick(View arg0) {			
			btnRecept.setText("");
	}};			
	OnClickListener btnRecept_Click =new OnClickListener(){
		public void onClick(View arg0) {	
			
			iv_intFocusField=CItemFactory.FIELD_RECEPT;
			ActCalculatorInput.INPUT_TYPE=ActCalculatorInput.INPUT_TYPE_STRING;
			Intent l_intent=new Intent(ActItemEditor.this,ActCalculatorInput.class);
			startActivityForResult(l_intent, CDictionary.ACTIVEID_CALCULATORINPUT);
			
	}};
	OnClickListener btnClearMemo_Click =new OnClickListener(){
		public void onClick(View arg0) {			
			
			txtMemo.setText("");
	}};	
	OnClickListener btnCatalogClear_Click =new OnClickListener(){
		public void onClick(View arg0) {			
			
			btnCatalog.setText("");
	}};	
	OnClickListener btnCatalogSubClear_Click =new OnClickListener(){
		public void onClick(View arg0) {			
			
			btnCatalogSub.setText("");
	}};		
	private  void InicialComponent() {
		btnOk=(Button)findViewById(R.id.ItemEditor_btnOk);
		btnOk.setOnClickListener(btnOk_Click);
		btnCancel=(Button)findViewById(R.id.ItemEditor_btnCancel);
		btnCancel.setOnClickListener(btnCancel_Click);
		btnClearMoney=(ImageButton)findViewById(R.id.ItemEditor_btnClearMoney);
		btnClearMoney.setOnClickListener(btnClearMoney_Click);
		btnClearMemo=(ImageButton)findViewById(R.id.ItemEditor_btnClearMemo);
		btnClearMemo.setOnClickListener(btnClearMemo_Click);		
		btnMoney=(Button)findViewById(R.id.ItemEditor_btnMoney);
		btnMoney.setOnClickListener(btnMoney_Click);
		txtMemo=(EditText)findViewById(R.id.ItemEditor_txtMemo);
		txtDate=(EditText)findViewById(R.id.ItemEditor_txtDate);
		btnCatalog=(Button)findViewById(R.id.ItemEditor_btnCatalog);
		btnCatalog.setOnClickListener(btnCatalog_Click);
		btnCatalogSub=(Button)findViewById(R.id.ItemEditor_btnCatalogSub);
		btnCatalogSub.setOnClickListener(btnCatalogSub_Click);
		btnProject=(Button)findViewById(R.id.ItemEditor_btnProject);
		btnProject.setOnClickListener(btnProject_Click);
		
		btnCatalogClear=(ImageButton)findViewById(R.id.ItemEditor_btnCatalogClear);
		btnCatalogClear.setOnClickListener(btnCatalogClear_Click);
		btnCatalogSubClear=(ImageButton)findViewById(R.id.ItemEditor_btnCatalogSubClear);
		btnCatalogSubClear.setOnClickListener(btnCatalogSubClear_Click);
		
		btnDate=(ImageButton)findViewById(R.id.ItemEditor_btnCalendar);
		btnDate.setOnClickListener(btnDate_Click);
		btnProjectClear=(ImageButton)findViewById(R.id.ItemEditor_btnProjectClear);
		btnProjectClear.setOnClickListener(btnProjectClear_Click);
		btnAccount=(Button)findViewById(R.id.ItemEditor_btnAccount);
		btnAccount.setOnClickListener(btnAccount_Click);
		
		btnClearRecept=(ImageButton)findViewById(R.id.ItemEditor_btnClearRecept);
		btnClearRecept.setOnClickListener(btnClearRecept_Click);
		btnRecept=(Button)findViewById(R.id.ItemEditor_btnRecept);
		btnRecept.setOnClickListener(btnRecept_Click);
		lblTitle=(TextView)findViewById(R.id.ItemEditor_lblTitle);
		// reset ui information
		Calendar l_calendar=Calendar.getInstance();
		txtDate.setText(CDateUtility.GetFormatedDateToday());
		ResetCodeItem();
		
		// set default information
		CCode[] l_codes=CDictionary.CCONTEXT.GetCodeFactory().GetByType(CDictionary.EDITOR_TYPE_DEFAULT);
		
		if(l_codes!=null){
			Log.d(CDictionary.DEBUG_TAG, "�w�]��Ʃ��ӡG"+String.valueOf(l_codes.length));
			for(int i=0 ;i<l_codes.length;i++){
				if(CDictionary.EDITOR_TYPE_PROJECT.equals( l_codes[i].GetKey())){
					btnProject.setText( l_codes[i].GetValue());
				}
				if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_INCOME){
					if(CDictionary.EDITOR_TYPE_CATALOG_INCOME.equals( l_codes[i].GetKey())){
						btnCatalog.setText( l_codes[i].GetValue());
						iv_catalogSubs=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(
								l_codes[i].GetName());
					}
					if(CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME.equals( l_codes[i].GetKey())){
						btnCatalogSub.setText( l_codes[i].GetValue());
					}
				}else if(EDITOR_MODE==CDictionary.ITEMEDITOR_MODE_PAYMENT){
					if(CDictionary.EDITOR_TYPE_CATALOG_PAYMENT.equals( l_codes[i].GetKey())){
						btnCatalog.setText( l_codes[i].GetValue());
						iv_catalogSubs=CDictionary.CCONTEXT.GetCodeFactory().GetByKey(
								l_codes[i].GetName());
					}
					if(CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT.equals( l_codes[i].GetKey())){
						btnCatalogSub.setText( l_codes[i].GetValue());
					}				
				}				
				
			}
		}
	}
	
	Button btnOk=null;
	Button btnCancel=null;
	Button btnMoney=null;
	Button btnAccount=null;
	Button btnRecept=null;
	EditText txtDate=null;
	Button btnCatalog=null;
	Button btnCatalogSub=null;
	Button btnProject=null;
	EditText txtMemo=null;
	TextView lblTitle=null;
	ImageButton btnClearMoney=null;
	ImageButton btnClearMemo=null;
	ImageButton btnClearRecept=null;
	ImageButton btnCatalogClear=null;
	ImageButton btnCatalogSubClear=null;
	ImageButton btnProjectClear=null;
	ImageButton btnDate=null;
}
