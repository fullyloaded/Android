package tw.org.iii.Moneybook.lib.da;

public class CCodeQueryKey implements IQueryKey {

	private String iv_strSql="";
	public CCodeQueryKey(){
		iv_strSql="SELECT * FROM "+CCodeFactory.DB_TABLENAME_CODE+" WHERE 1=1 ";
	}
	public void AddTypeEqual(String p_str){
		AddFieldEqual(CCodeFactory.FIELD_TYPE,p_str);
	}
	public void AddKeyEqual(String p_str){
		AddFieldEqual(CCodeFactory.FIELD_KEY,p_str);
	}
	public void AddNameEqual(String p_str){
		AddFieldEqual(CCodeFactory.FIELD_NAME,p_str);
	}
	public void AddValueEqual(String p_str){
		AddFieldEqual(CCodeFactory.FIELD_VALUE,p_str);
	}
	private void AddFieldEqual(String p_strField,String p_strValue){
		iv_strSql+=" AND "+p_strField+"='"+p_strValue+"'";
	}
	@Override
	public String ToSqlCommand() {		
		return iv_strSql + " ORDER BY "+CCodeFactory.FIELD_VALUE ;
	}

}
