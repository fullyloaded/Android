package tw.org.iii.Moneybook.lib.util;

import java.text.DecimalFormat;
import java.util.Calendar;

public class CDateUtility {

	public static String ToDateDbString(Calendar p_calendar){
		
		DecimalFormat l_format=new DecimalFormat("00");
		return String.valueOf(p_calendar.get(Calendar.YEAR))+
			l_format.format(p_calendar.get(Calendar.MONTH)+1)+
			l_format.format(p_calendar.get(Calendar.DATE));			
	}
	public static  String ToTimeDbString(Calendar p_calendar){		
		DecimalFormat l_format=new DecimalFormat("00");
		return l_format.format(p_calendar.get(Calendar.HOUR))+
			l_format.format(p_calendar.get(Calendar.MINUTE))+
			l_format.format(p_calendar.get(Calendar.SECOND));			
	}	
	public static  String ToDateTimeDbString(Calendar p_calendar){				
		return ToDateDbString(p_calendar)+ToDateTimeDbString(p_calendar);			
	}	
	public static  String GetNowDbString( ){
		return ToDateTimeDbString(Calendar.getInstance());
	}
	public static  String GetTodayDbString( ){
		return ToDateDbString(Calendar.getInstance());
	}
	public static  String GetFormatedDateToday( ){
		return GetFormatedDate(Calendar.getInstance());
	}
	public static  Calendar ToCalendarDate(String p_strYYYYMMDD){
		Calendar l_calendar=Calendar.getInstance();		
		l_calendar.set(Integer.parseInt(p_strYYYYMMDD.substring(0,4)),
				Integer.parseInt(p_strYYYYMMDD.substring(4,6))-1,
				Integer.parseInt(p_strYYYYMMDD.substring(6,8))
				);
		return l_calendar;
	}
	public static Calendar GetFirstDateOfMonth(Calendar p_calendar){		
		p_calendar.set(Calendar.DATE, 1);
		return p_calendar;
	}
	public static Calendar GetLastDateOfMonth(Calendar p_calendar){		
		p_calendar.add(Calendar.MONTH, 1);
		p_calendar.set(Calendar.DATE, 1);
		p_calendar.add(Calendar.DATE, -1);
		return p_calendar;
	}

	public static  Calendar ToCalendarDateTime(String p_strYYYYMMDDHHMMSS){
		Calendar l_calendar=Calendar.getInstance();		
		l_calendar.set(Integer.parseInt(p_strYYYYMMDDHHMMSS.substring(0,4)),
				Integer.parseInt(p_strYYYYMMDDHHMMSS.substring(4,6))-1,
				Integer.parseInt(p_strYYYYMMDDHHMMSS.substring(6,8)),
				Integer.parseInt(p_strYYYYMMDDHHMMSS.substring(8,10)),
				Integer.parseInt(p_strYYYYMMDDHHMMSS.substring(10,12)),
				Integer.parseInt(p_strYYYYMMDDHHMMSS.substring(12,14))
				);
		
		return l_calendar;
	}
	public  static String GetFormatedDate(Calendar p_calendar){
		DecimalFormat l_format=new DecimalFormat("00");
		return String.valueOf(p_calendar.get(Calendar.YEAR))+"-"+
			l_format.format(p_calendar.get(Calendar.MONTH)+1)+"-"+
			l_format.format(p_calendar.get(Calendar.DATE));		
	}
	public  static String GetFormatedDate(String p_strYYYYMMDDHHMMSS){
		
		return p_strYYYYMMDDHHMMSS.substring(0,4)+"-"+
		p_strYYYYMMDDHHMMSS.substring(4,6)+"-"+
		p_strYYYYMMDDHHMMSS.substring(6,8);
	}
	public  static String GetFormatedDateTime(String p_strYYYYMMDDHHMMSS){
		
		return p_strYYYYMMDDHHMMSS.substring(0,4)+"-"+
		p_strYYYYMMDDHHMMSS.substring(4,6)+"-"+
		p_strYYYYMMDDHHMMSS.substring(6,8)+" "+
		p_strYYYYMMDDHHMMSS.substring(8,10)+":"+
		p_strYYYYMMDDHHMMSS.substring(10,12)+":"+
		p_strYYYYMMDDHHMMSS.substring(12,14)
		;
	}
}
