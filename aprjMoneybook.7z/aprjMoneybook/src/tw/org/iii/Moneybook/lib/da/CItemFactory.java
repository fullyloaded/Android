package tw.org.iii.Moneybook.lib.da;

import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;
import tw.org.iii.Moneybook.ui.CContext;

public class CItemFactory {

	public final static String DB_TABLENAME_ITEM="tItem";
	public final static String FIELD_MONEY="fMoney";
	public final static String FIELD_DATE="fDate";
	public final static String FIELD_CATALOG="fCatalog";
	public final static String FIELD_CATALOGSUB="fCatalogSub";
	public final static String FIELD_ACCOUNT="fAccountId";
	public final static String FIELD_PROJECT="fProjectId";
	public final static String FIELD_MEMO="fMemo";
	public final static String FIELD_BUILDDATE="fBuildDate";	
	public final static String FIELD_PICTUREPATH="fPicturePath";
	public final static String FIELD_AUDIOPATH="fAudioPath";
	public final static String FIELD_LATITUDE="fLatitude";
	public final static String FIELD_LONGTITUDE="fLongitude";
	public final static String FIELD_RECEPT="fRECEPT";
	

	
	public CItem[] GetBySql(String p_strSql){
		CItem[] l_items=null;
		Cursor l_cursor=iv_context.GetDbManager().QueryBySql(p_strSql);
		l_cursor.moveToPosition(0);
		if(l_cursor.getCount()>0){
			l_items=new CItem[l_cursor.getCount()];
			for(int i=0;i<l_cursor.getCount();i++){			
				l_items[i]=new CItem();
				l_items[i].SetId(l_cursor.getInt(0));
				l_items[i].SetMoney(l_cursor.getDouble(1));
				l_items[i].SetDate(l_cursor.getString(2));
				l_items[i].SetCatalog(l_cursor.getString(3));
				l_items[i].SetCatalogSub(l_cursor.getString(4));
				l_items[i].SetAccount(l_cursor.getString(5));
				l_items[i].SetProject(l_cursor.getString(6));
				l_items[i].SetMemo(l_cursor.getString(7));
				l_items[i].SetBuildDate(l_cursor.getString(8));
				l_items[i].SetPicturePath(l_cursor.getString(9));
				l_items[i].SetAudioPath(l_cursor.getString(10));
				l_items[i].SetLatitude(l_cursor.getString(11));
				l_items[i].SetLongitude(l_cursor.getString(12));
				l_items[i].SetReceptNO(l_cursor.getString(13));			
				l_cursor.moveToNext();
			}
		}
		l_cursor.close();
		//iv_context.GetDbManager().Close();
		return l_items;
	}

	public CItem GetById( int p_intId){
		try{			
			CItem[] l_items=GetBySql("SELECT * FROM "+DB_TABLENAME_ITEM+" WHERE _id="+String.valueOf(p_intId));
			if(l_items==null)
				return null;
			return l_items[0];
		}catch(Exception ex){
			//Toast.makeText(p_context, ex.getMessage(), Toast.LENGTH_LONG).show();
			return null;
		}				
	}
	public CItem[] GetByKey(IQueryKey p_key){
		return GetBySql(p_key.ToSqlCommand());
	}
	
	public CItem[] GetItemByDateRange( String p_strYYYYMMDDStart,String p_strYYYYMMDDEnd){

		try{
			
			String l_str="SELECT * FROM "+DB_TABLENAME_ITEM+" WHERE ";
			l_str+=" "+FIELD_DATE+"  >='"+p_strYYYYMMDDStart+"' AND "+FIELD_DATE+" <= '"+p_strYYYYMMDDEnd+"'";

			return GetBySql(l_str);
		}catch(Exception ex){
			//Toast.makeText(p_context, ex.getMessage(), Toast.LENGTH_LONG).show();
			return null;
		}
				
	}
	
	CContext iv_context;
	public CItemFactory(CContext p_context){
		iv_context=p_context;
	}
	public CItem Create(){
		return new CItem();
	}
	public void Update(CItem p_item){
		ContentValues l_value=new ContentValues();
		l_value.put(CItemFactory.FIELD_ACCOUNT, p_item.GetAccountId());
		l_value.put(CItemFactory.FIELD_AUDIOPATH, p_item.GetAudioPath());
		l_value.put(CItemFactory.FIELD_BUILDDATE, p_item.GetBuildDate());
		l_value.put(CItemFactory.FIELD_CATALOG, p_item.GetCatalog());
		l_value.put(CItemFactory.FIELD_CATALOGSUB, p_item.GetCatalogSub());
		l_value.put(CItemFactory.FIELD_DATE, p_item.GetDate());
		l_value.put(CItemFactory.FIELD_LATITUDE, p_item.GetLatitude());
		l_value.put(CItemFactory.FIELD_LONGTITUDE, p_item.GetLongitude());
		l_value.put(CItemFactory.FIELD_MEMO, p_item.GetMemo());
		l_value.put(CItemFactory.FIELD_MONEY, p_item.GetMoney());
		l_value.put(CItemFactory.FIELD_PICTUREPATH, p_item.GetPicturePath());
		l_value.put(CItemFactory.FIELD_PROJECT, p_item.GetProject());
		l_value.put(CItemFactory.FIELD_RECEPT, p_item.GetReceptNO());
		if(p_item.GetId()<0){
			iv_context.GetDbManager().Insert(DB_TABLENAME_ITEM, l_value);			
		}
		else{
			iv_context.GetDbManager().Update(DB_TABLENAME_ITEM, l_value, p_item.GetId());
		}
			
	}
	public void Delete(CItem p_item){
		iv_context.GetDbManager().Delete(DB_TABLENAME_ITEM, p_item.GetId());
	}
	
}
