package tw.org.iii.Moneybook.lib.util;

public class CStringUtility {
	/* <Description>���o�r�ꪺ�̫�@�X </Description>
	 * <Parameter name="p_str" type="String">�ؼЦr��</Parameter>
	 * <Return type="String">�r�ꪺ�̫�@�X</Return>
	 * <Date>2012-05-20</Date>
	 */	
	public static String GetLatestChar(String p_str){		
		if(p_str.length()>0)
			return p_str.substring(p_str.length()-1,p_str.length());
		return "";
	}
	
	public static String GetRight(String p_str,int p_intLength){		
		if(p_str.length()>=p_intLength)
			return p_str.substring(0,p_intLength);
		return "";
	}
}
