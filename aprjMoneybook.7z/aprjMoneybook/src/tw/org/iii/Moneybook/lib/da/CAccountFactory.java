package tw.org.iii.Moneybook.lib.da;

import android.content.ContentValues;
import android.database.Cursor;
import tw.org.iii.Moneybook.ui.CContext;

public class CAccountFactory {
	public final static String DB_TABLENAME_ACCOUNT="tAccount";
	
	public final static String FIELD_NAME="fName";
	public final static String FIELD_MONEY="fMoney";
	public final static String FIELD_ACCOUNT="fAccount";
	public final static String FIELD_PASSWORD="fPassword";
	public final static String FIELD_RATE="fRate";
	public final static String FIELD_MEMO="fMemo";
	public final static String FIELD_BRANCH="fBranch";
	public final static String FIELD_BANK="fBank";
	public final static String FIELD_TYPE="fType";
	
	CContext iv_context;
	public CAccountFactory(CContext p_context){
		iv_context=p_context;
	}
	public CAccount Create(){
		return new CAccount();
	}
	public String GetNameById(String p_strId){
		CAccount[] l_accounts=GetBySql("SELECT * FROM "+DB_TABLENAME_ACCOUNT+" WHERE _id="+p_strId);
		if(l_accounts==null)
			return "";
		return l_accounts[0].GetName();
	}
	private CAccount[] GetBySql( String p_strSql){
		CAccount[] l_items=null;
		Cursor l_cursor=iv_context.GetDbManager().QueryBySql(p_strSql);
		l_cursor.moveToPosition(0);
		if(l_cursor.getCount()>0){
			l_items=new CAccount[l_cursor.getCount()];
			for(int i=0;i<l_cursor.getCount();i++){			
				l_items[i]=new CAccount();
				l_items[i].SetId(l_cursor.getInt(0));				
				l_items[i].SetAccount(l_cursor.getString(1));
				l_items[i].SetBank(l_cursor.getString(2));
				l_items[i].SetBranch(l_cursor.getString(3));
				l_items[i].SetMemo(l_cursor.getString(4));				
				l_items[i].SetMoney(l_cursor.getDouble(5));
				l_items[i].SetName(l_cursor.getString(6));
				l_items[i].SetPassword(l_cursor.getString(7));
				l_items[i].SetRate(l_cursor.getDouble(8));
				l_items[i].SetType(l_cursor.getString(9));				
				l_cursor.moveToNext();
			}
		}
		l_cursor.close();
		return l_items;
	}
	
	public CAccount[] GetAll(){
		return GetBySql("SELECT * FROM "+CAccountFactory.DB_TABLENAME_ACCOUNT+
				" ORDER BY "+CAccountFactory.FIELD_NAME+" ASC");
	}
	
	public void Delete(CAccount p_item){
		iv_context.GetDbManager().Delete(CAccountFactory.DB_TABLENAME_ACCOUNT, p_item.GetId());
	}
	
	public void Update(CAccount p_item){
		ContentValues l_value=new ContentValues();
		l_value.put(CAccountFactory.FIELD_ACCOUNT, p_item.GetAccount());
		l_value.put(CAccountFactory.FIELD_BANK, p_item.GetBank());
		l_value.put(CAccountFactory.FIELD_BRANCH, p_item.GetBranch());
		l_value.put(CAccountFactory.FIELD_MEMO, p_item.GetMemo());
		l_value.put(CAccountFactory.FIELD_MONEY, p_item.GetMoney());
		l_value.put(CAccountFactory.FIELD_NAME, p_item.GetName());
		l_value.put(CAccountFactory.FIELD_PASSWORD, p_item.GetPassword());
		l_value.put(CAccountFactory.FIELD_RATE, p_item.GetRate());
		l_value.put(CAccountFactory.FIELD_TYPE, p_item.GetType());

		if(p_item.GetId()<0){
			iv_context.GetDbManager().Insert(CAccountFactory.DB_TABLENAME_ACCOUNT, l_value);			
		}
		else{
			iv_context.GetDbManager().Update(CAccountFactory.DB_TABLENAME_ACCOUNT, l_value, p_item.GetId());
		}
			
	}
	public CAccount GetById(int p_intId) {
		try{			
			CAccount[] l_accounts=GetBySql("SELECT * FROM "+DB_TABLENAME_ACCOUNT+" WHERE _id="+String.valueOf(p_intId));
			if(l_accounts==null)
				return null;
			return l_accounts[0];
		}catch(Exception ex){
			return null;
		}	
	}
	
	
	
	
	
	
	
	
}
