package tw.org.iii.Moneybook.lib.da;

public class CItem {

	private int iv_intId=-1;
	private double iv_dblMoney;
	private String iv_strTitle="";
	private String iv_strDate="";
	private String iv_strCatalog="";
	private String iv_strCatalogSub="";
	private String iv_strAccount;
	private String iv_strProject;
	private String iv_strMemo="";
	private String iv_strBuildDate="";
	private String iv_strPicturePath="";
	private String iv_strAudioPath="";
	private String iv_strLatitude="";
	private String iv_strLongitude="";
	private String iv_strReceptNO="";
	
	public CItem(){
	
	}
	
	
	
	
	public void SetId(int iv_intId) {
		this.iv_intId = iv_intId;
	}
	public int GetId() {
		return iv_intId;
	}
	public void SetMoney(double iv_dblMoney) {
		this.iv_dblMoney = iv_dblMoney;
	}
	public double GetMoney() {
		return iv_dblMoney;
	}
	public void SetTitle(String iv_strTitle) {
		this.iv_strTitle = iv_strTitle;
	}
	public String GetTitle() {
		return iv_strTitle;
	}
	public void SetDate(String iv_strDate) {
		this.iv_strDate = iv_strDate;
	}
	public String GetDate() {
		return iv_strDate;
	}
	public void SetCatalog(String iv_strCatalog) {
		this.iv_strCatalog = iv_strCatalog;
	}
	public String GetCatalog() {
		return iv_strCatalog;
	}

	public void SetMemo(String iv_strMemo) {
		this.iv_strMemo = iv_strMemo;
	}
	public String GetMemo() {
		return iv_strMemo;
	}
	public void SetBuildDate(String iv_strBuildDate) {
		this.iv_strBuildDate = iv_strBuildDate;
	}
	public String GetBuildDate() {
		return iv_strBuildDate;
	}
	public void SetPicturePath(String iv_strPicturePath) {
		this.iv_strPicturePath = iv_strPicturePath;
	}
	public String GetPicturePath() {
		return iv_strPicturePath;
	}
	public void SetAudioPath(String iv_strAudioPath) {
		this.iv_strAudioPath = iv_strAudioPath;
	}
	public String GetAudioPath() {
		return iv_strAudioPath;
	}
	public void SetLatitude(String iv_strLatitude) {
		this.iv_strLatitude = iv_strLatitude;
	}
	public String GetLatitude() {
		return iv_strLatitude;
	}
	public void SetLongitude(String iv_strLongitude) {
		this.iv_strLongitude = iv_strLongitude;
	}
	public String GetLongitude() {
		return iv_strLongitude;
	}
	public void SetAccount(String iv_strAccount) {
		this.iv_strAccount = iv_strAccount;
	}
	public String GetAccountId() {
		return iv_strAccount;
	}
	public void SetProject(String iv_strProject) {
		this.iv_strProject = iv_strProject;
	}
	public String GetProject() {
		return iv_strProject;
	}
	public void SetCatalogSub(String iv_strCatalogSub) {
		this.iv_strCatalogSub = iv_strCatalogSub;
	}
	public String GetCatalogSub() {
		return iv_strCatalogSub;
	}




	public void SetReceptNO(String iv_strReceptNO) {
		this.iv_strReceptNO = iv_strReceptNO;
	}




	public String GetReceptNO() {
		return iv_strReceptNO;
	}
	
	
	
}
