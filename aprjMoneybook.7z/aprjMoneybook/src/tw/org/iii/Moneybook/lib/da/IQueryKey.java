package tw.org.iii.Moneybook.lib.da;

public interface IQueryKey {

	public String ToSqlCommand();
}
