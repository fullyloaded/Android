package tw.org.iii.Moneybook.lib.da;

public class CAccount {

	private int iv_intId;
	private String iv_strName;
	private double iv_dblMoney;
	private String iv_strAccount;
	private String iv_strPassword;
	private double iv_dblRate;
	private String iv_strType;
	private String iv_strBank;
	private String iv_strBranch;
	private String iv_strMemo;
	
	public void AddMoney(double p_dbl){
		iv_dblMoney+=p_dbl;
	}
	
	
	public CAccount(){
		iv_intId=-1;
	}
	
	public void SetId(int id) {
		iv_intId = id;
	}
	public int GetId() {
		return iv_intId;
	}
	public void SetMoney(double money) {
		iv_dblMoney = money;
	}
	public double GetMoney() {
		return iv_dblMoney;
	}
	public void SetRate(double rate) {
		iv_dblRate = rate;
	}
	public double GetRate() {
		return iv_dblRate;
	}
	public void SetAccount(String iv_strAccount) {
		this.iv_strAccount = iv_strAccount;
	}
	public String GetAccount() {
		return iv_strAccount;
	}
	public void SetPassword(String iv_strPassword) {
		this.iv_strPassword = iv_strPassword;
	}
	public String GetPassword() {
		return iv_strPassword;
	}
	public void SetType(String iv_strType) {
		this.iv_strType = iv_strType;
	}
	public String GetType() {
		return iv_strType;
	}
	public void SetBank(String iv_strBank) {
		this.iv_strBank = iv_strBank;
	}
	public String GetBank() {
		return iv_strBank;
	}
	public void SetBranch(String iv_strBranch) {
		this.iv_strBranch = iv_strBranch;
	}
	public String GetBranch() {
		return iv_strBranch;
	}
	public void SetMemo(String iv_strMemo) {
		this.iv_strMemo = iv_strMemo;
	}
	public String GetMemo() {
		return iv_strMemo;
	}
	public void SetName(String iv_strName) {
		this.iv_strName = iv_strName;
	}
	public String GetName() {
		return iv_strName;
	}
	
}

