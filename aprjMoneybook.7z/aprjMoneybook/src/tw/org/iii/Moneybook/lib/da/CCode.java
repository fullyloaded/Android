package tw.org.iii.Moneybook.lib.da;

public class CCode {

	private int iv_intId=-1;
	private String iv_strKey="";
	private String iv_strValue="";
	private String iv_strName="";
	private String iv_strType="";
	public void SetId(int iv_intId) {
		this.iv_intId = iv_intId;
	}
	public int GetId() {
		return iv_intId;
	}
	public void SetKey(String iv_strKey) {
		this.iv_strKey = iv_strKey;
	}
	public String GetKey() {
		return iv_strKey;
	}
	public void SetValue(String iv_strValue) {
		this.iv_strValue = iv_strValue;
	}
	public String GetValue() {
		return iv_strValue;
	}
	public void SetName(String iv_strName) {
		this.iv_strName = iv_strName;
	}
	public String GetName() {
		return iv_strName;
	}
	public void SetType(String iv_strType) {
		this.iv_strType = iv_strType;
	}
	public String GetType() {
		return iv_strType;
	}
}
