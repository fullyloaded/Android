package tw.org.iii.Moneybook.lib.da;

import java.util.Calendar;

import tw.org.iii.Moneybook.lib.util.CDateUtility;

public class CItemQueryKey implements IQueryKey {

	private String iv_strSql="";
	public CItemQueryKey(){
		iv_strSql="SELECT * FROM "+CItemFactory.DB_TABLENAME_ITEM+" WHERE 1=1 ";
	}
	public void AddCatalogEqual(String p_str){
		AddFieldEqual(CItemFactory.FIELD_CATALOG,p_str);
	}
	public void AddCatalogSubEqual(String p_str){
		AddFieldEqual(CItemFactory.FIELD_CATALOGSUB,p_str);
	}
	public void AddProjectEqual(String p_str){
		AddFieldEqual(CItemFactory.FIELD_PROJECT,p_str);
	}
	public void AddAccountIdEqual(String p_str){
		AddFieldEqual(CItemFactory.FIELD_ACCOUNT,p_str);		
	}
	
	public void AddPaymentFlag(){
		iv_strSql+=" AND "+CItemFactory.FIELD_MONEY+"<0 ";
	}
	public void AddIncomeFlag(){
		iv_strSql+=" AND "+CItemFactory.FIELD_MONEY+">0 ";
	}
	public void AddDateRange(Calendar  p_calendarStart,Calendar  p_calendarEnd){
		AddFieldRange(CItemFactory.FIELD_DATE,
				CDateUtility.ToDateDbString(p_calendarStart)+"000000",
				CDateUtility.ToDateDbString(p_calendarEnd)+"999999");
	}
	private void AddFieldEqual(String p_strField,String p_strValue){
		iv_strSql+=" AND "+p_strField+"='"+p_strValue+"'";
	}	
	private void AddFieldRange(String p_strField,String p_strStart,String p_strEnd){		
		iv_strSql+=" AND ("+p_strField+"  >='"+p_strStart+"' AND "+p_strField+" <= '"+p_strEnd+"') ";
	}
	
	@Override
	public String ToSqlCommand() {		
		return iv_strSql + " ORDER BY "+CItemFactory.FIELD_DATE ;
	}

}
