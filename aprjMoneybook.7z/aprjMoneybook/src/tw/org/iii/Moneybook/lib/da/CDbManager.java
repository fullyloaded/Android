package tw.org.iii.Moneybook.lib.da;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CDbManager extends SQLiteOpenHelper {
	private final static String DB_NAME="dbMoneybook.db";
	
	private final static int DB_VERSION=1;
	private Context iv_context=null;
	
	private void InicialAccount(SQLiteDatabase p_db){
		p_db.execSQL("INSERT INTO "+CAccountFactory.DB_TABLENAME_ACCOUNT+" VALUES('','','','',0,'�{��','',0,'�{��')");
	}
	
	public void ExecuteSql(String p_strSql){
		getWritableDatabase().execSQL(p_strSql);
	}
	
	private String GetAccountTableCreate(){
		String l_str="CREATE TABLE ";
		l_str+=CAccountFactory.DB_TABLENAME_ACCOUNT+"(";
		l_str+="_id INTEGER PRIMARY KEY , ";
		l_str+=" "+CAccountFactory.FIELD_ACCOUNT+" Text ,";
		l_str+=" "+CAccountFactory.FIELD_BANK+" Text ,";
		l_str+=" "+CAccountFactory.FIELD_BRANCH+" Text ,";
		l_str+=" "+CAccountFactory.FIELD_MEMO+" Text ,";
		l_str+=" "+CAccountFactory.FIELD_MONEY+" DOUBLE ,";
		l_str+=" "+CAccountFactory.FIELD_NAME+" Text,";
		l_str+=" "+CAccountFactory.FIELD_PASSWORD+" Text,";
		l_str+=" "+CAccountFactory.FIELD_RATE+" DOUBLE,";
		l_str+=" "+CAccountFactory.FIELD_TYPE+" Text ";
		l_str+=" )";
		return l_str;
	}		
	private String GetCodeTableCreate(){
		String l_str="CREATE TABLE ";
		l_str+=CCodeFactory.DB_TABLENAME_CODE+"(";
		l_str+="_id INTEGER PRIMARY KEY , ";
		l_str+=" "+CCodeFactory.FIELD_KEY+" Text ,";
		l_str+=" "+CCodeFactory.FIELD_NAME+" Text ,";
		l_str+=" "+CCodeFactory.FIELD_VALUE+" Text,";
		l_str+=" "+CCodeFactory.FIELD_TYPE+" Text ";
		l_str+=" )";
		return l_str;
	}	
	private String GetItemTableCreate(){
		String l_str="CREATE TABLE ";
		l_str+=CItemFactory.DB_TABLENAME_ITEM+"(";
		l_str+="_id INTEGER PRIMARY KEY , ";
		l_str+=" "+CItemFactory.FIELD_MONEY+" DOUBLE NOT NULL,";
		l_str+=" "+CItemFactory.FIELD_DATE+" Text NOT NULL,";
		l_str+=" "+CItemFactory.FIELD_CATALOG+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_CATALOGSUB+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_ACCOUNT+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_PROJECT+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_MEMO+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_BUILDDATE+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_PICTUREPATH+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_AUDIOPATH+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_LATITUDE+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_LONGTITUDE+" TEXT,";
		l_str+=" "+CItemFactory.FIELD_RECEPT+" TEXT";
		l_str+=" )";
		return l_str;
	}	
	public void Close(){
		getWritableDatabase().close();
	}
	
	
	public CDbManager(Context p_context) {
		super(p_context,  DB_NAME, null, DB_VERSION);
		iv_context=p_context;
	}

	public Cursor QueryBySql(String p_strSql){		
		Cursor l_cursor=getReadableDatabase().rawQuery(p_strSql, null);
			((Activity)iv_context).startManagingCursor(l_cursor);
		return l_cursor;
	}
	
	public long Insert(String p_table ,ContentValues p_values){
		return getWritableDatabase().insert(p_table, null, p_values);	
	}
	
	public long Update(String p_table ,ContentValues p_content,int p_intId){
		return getWritableDatabase().update(p_table, p_content, "_id="+String.valueOf(p_intId), null);		
	}
	
	public long Delete(String p_table ,int p_intId){
		return getWritableDatabase().delete(p_table, "_id="+String.valueOf(p_intId), null);
	}
	@Override
	public void onCreate(SQLiteDatabase arg0) {
		arg0.execSQL(GetItemTableCreate());
		arg0.execSQL(GetCodeTableCreate());
		arg0.execSQL(GetAccountTableCreate());
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub

	}

}
