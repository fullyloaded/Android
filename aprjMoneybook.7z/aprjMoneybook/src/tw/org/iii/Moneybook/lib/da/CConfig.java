package tw.org.iii.Moneybook.lib.da;

import android.graphics.Color;
import tw.org.iii.Moneybook.ui.CContext;

public class CConfig {
	public final static String FIELD_PASSWORD=""; 
	CContext iv_context;
	
	public CConfig(CContext p_context){
		iv_context=p_context;
	}
	
	public int GetColorHomeButton1(){
		return Color.rgb(239, 247, 253);
	}
	 
	public int GetChartBarColor(){
		return Color.rgb(239, 169,49 );
	}
	
	public int GetChartBackgroundColor1(){
		return Color.rgb(206, 227, 255);
	}
	public int GetChartLineColor2(){
		return Color.rgb(237, 28,36 );
	} 
	public int GetChartBackgroundColor2(){
		return Color.rgb(255, 255,255 );
	}
	
	
	
}
