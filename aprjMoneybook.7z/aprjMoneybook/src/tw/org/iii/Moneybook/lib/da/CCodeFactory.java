package tw.org.iii.Moneybook.lib.da;

import tw.org.iii.Moneybook.ui.CContext;
import tw.org.iii.Moneybook.ui.CDictionary;
import android.content.ContentValues;
import android.database.Cursor;

public class CCodeFactory {

	public final static String DB_TABLENAME_CODE="tCode";
	public final static String FIELD_TYPE="fType";
	public final static String FIELD_NAME="fName";
	public final static String FIELD_KEY="fKey";
	public final static String FIELD_VALUE="fValue";
	
	public final static String TYPE_CATALOG_PAYMENT="TYPE_CATALOG_PAYMENT";
	public final static String TYPE_CATALOG_INCOME="TYPE_CATALOG_INCOME";

	
	private CCode[] GetBySql( String p_strSql){
		CCode[] l_items=null;
		Cursor l_cursor=iv_context.GetDbManager().QueryBySql(p_strSql);
		l_cursor.moveToPosition(0);
		if(l_cursor.getCount()>0){
			l_items=new CCode[l_cursor.getCount()];
			for(int i=0;i<l_cursor.getCount();i++){			
				l_items[i]=new CCode();
				l_items[i].SetId(l_cursor.getInt(0));				
				l_items[i].SetKey(l_cursor.getString(1));
				l_items[i].SetName(l_cursor.getString(2));
				l_items[i].SetValue(l_cursor.getString(3));
				l_items[i].SetType(l_cursor.getString(4));				
				l_cursor.moveToNext();
			}
		}
		l_cursor.close();
		return l_items;
	}
	public CCode[] GetPaymentCatalogSub(int p_intId){
		CCode l_code=new CCode();
		l_code.SetId(p_intId);
		return GetPaymentCatalogSub(l_code);
	}
	public CCode[] GetIncomeCatalogSub(int p_intId){
		CCode l_code=new CCode();
		l_code.SetId(p_intId);
		return GetIncomeCatalogSub(l_code);
	}
	public CCode[] GetIncomeCatalogSub(CCode p_code){
		return GetCatalogSub(p_code,CDictionary.EDITOR_TYPE_CATALOGSUB_INCOME);
	}
	public CCode[] GetPaymentCatalogSub(CCode p_code){		
		return GetCatalogSub(p_code,CDictionary.EDITOR_TYPE_CATALOGSUB_PAYMENT);
	}
	
	public CCode[] getAll(){		
		return GetByType("SELECT * FROM "+DB_TABLENAME_CODE);
	}
	
	public void DeleteByKey(String p_strKey){
		iv_context.GetDbManager().ExecuteSql("DELETE FROM "+CCodeFactory.DB_TABLENAME_CODE+" WHERE "+
			CCodeFactory.FIELD_KEY+"='"+p_strKey+"'");
	}
	private CCode[] GetCatalogSub(CCode p_code, String p_strType){
		
		String l_str="SELECT * FROM "+DB_TABLENAME_CODE+" WHERE ";
		l_str+=" "+FIELD_TYPE+"  ='"+p_strType+"'";
		l_str+=" AND fKey= '"+String.valueOf(p_code.GetId())+"'";
		l_str+=" ORDER BY "+FIELD_VALUE+"";
		return GetBySql(l_str);
	}
	
	public  CCode[] GetByKeyAndType(String p_strKey, String p_strType){
		String l_str="SELECT * FROM "+DB_TABLENAME_CODE+" WHERE ";
		l_str+=" "+FIELD_TYPE+"  ='"+p_strType+"'";
		l_str+=" AND "+FIELD_KEY+"= '"+p_strKey+"'";
		l_str+=" ORDER BY "+FIELD_VALUE+"";
		return GetBySql(l_str);
	}
	
	public CCode[] GetByKey(IQueryKey p_key){
		return GetBySql(p_key.ToSqlCommand());
	}
	
	public void Create(String p_strType,String p_strKey,String p_strName, String p_strValue){
		CCode l_code=Create();
		l_code.SetType(p_strType);
		l_code.SetKey(p_strKey);
		l_code.SetName(p_strName);
		l_code.SetValue(p_strValue);
		Update(l_code);
	}

	public  CCode[] GetByKey(String p_strKey){
		String l_str="SELECT * FROM "+DB_TABLENAME_CODE+" WHERE ";		
		l_str+="  "+FIELD_KEY+"= '"+p_strKey+"'";
		l_str+=" ORDER BY "+FIELD_VALUE+"";
		return GetBySql(l_str);
	}
	public CCode[] GetByType( String p_strType)
	{
		try{			
			String l_str="SELECT * FROM "+DB_TABLENAME_CODE+" WHERE ";
			l_str+=" "+FIELD_TYPE+"  ='"+p_strType+"' ORDER BY "+FIELD_VALUE+"";
			return GetBySql(l_str);
		}catch(Exception ex){			
			return null;
		}
				
	}
	
	CContext iv_context;
	public CCodeFactory(CContext p_context){
		iv_context=p_context;
	}
	public CCode Create(){
		return new CCode();
	}
	public void Update(CCode p_item){
		ContentValues l_value=new ContentValues();
		l_value.put(CCodeFactory.FIELD_KEY, p_item.GetKey());
		l_value.put(CCodeFactory.FIELD_NAME, p_item.GetName());
		l_value.put(CCodeFactory.FIELD_TYPE, p_item.GetType());
		l_value.put(CCodeFactory.FIELD_VALUE, p_item.GetValue());
		if(p_item.GetId()<0){
			iv_context.GetDbManager().Insert(DB_TABLENAME_CODE, l_value);			
		}
		else{
			iv_context.GetDbManager().Update(DB_TABLENAME_CODE, l_value, p_item.GetId());
		}			
	}
	public void Delete(CCode p_item){
		iv_context.GetDbManager().Delete(DB_TABLENAME_CODE, p_item.GetId());
	}
	
}
