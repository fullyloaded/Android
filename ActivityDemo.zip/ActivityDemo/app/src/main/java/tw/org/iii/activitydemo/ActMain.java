package tw.org.iii.activitydemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActMain extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);
        InitialComponent();

    }
    View.OnClickListener btnAct2_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            Intent intent=new Intent(ActMain.this,Act2.class);
            startActivity(intent);

        }
    };
    View.OnClickListener btnSend_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            Bundle bund = new Bundle();
            bund.putString("KK","Marco");

            Intent intent=new Intent(ActMain.this,Act3.class);
            intent.putExtras(bund);
            startActivity(intent);

        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if(data==null){
            lblTitle.setText("沒有設定管理員");
            return;
        }
        if(data.getExtras()==null){
            lblTitle.setText("沒有設定包裹");
            return;
        }

        if(requestCode==689){
            String r=data.getExtras().getString("KK");
            lblTitle.setText("你的選擇是：" + r);
        }
        if(requestCode==122){
            String r=data.getExtras().getString("JJ");
            lblTitle.setText("收件人是：" + r);
        }
    }

    View.OnClickListener btnReceive_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            Intent intent=new Intent(ActMain.this,Act4.class);
            startActivityForResult(intent, 689);

        }
    };
    View.OnClickListener btnList_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            Intent intent=new Intent(ActMain.this,ActList.class);
            startActivityForResult(intent,122);

        }
    };

    private void InitialComponent() {
        lblTitle=(TextView)findViewById(R.id.lblTitle);
        btnAct2=(Button)findViewById(R.id.btnNew);
        btnAct2.setOnClickListener(btnAct2_click);
        btnSend=(Button)findViewById(R.id.btnSend);
        btnSend.setOnClickListener(btnSend_click);
        btnReceive=(Button)findViewById(R.id.btnReceive);
        btnReceive.setOnClickListener(btnReceive_click);
        btnList=(Button)findViewById(R.id.btnList);
        btnList.setOnClickListener(btnList_click);
    }
    TextView lblTitle;
    Button btnAct2;
    Button btnSend;
    Button btnReceive;
    Button btnList;


}










