package tw.org.iii.calcdemo;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActMain extends Activity {

    int number1=0;
    String op="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);
        InitialComponent();
    }
    View.OnClickListener btn0_Click = new View.OnClickListener() {
        public void onClick(View v) {


        }
    };
    View.OnClickListener btn1_Click = new View.OnClickListener() {
        public void onClick(View v) {

            int l_int=Integer.parseInt(lblNumber.getText().toString());
            if(l_int==0)
                lblNumber.setText("1");
            else
                lblNumber.setText(lblNumber.getText().toString()+"1");
        }
    };
    View.OnClickListener btn2_Click = new View.OnClickListener() {
        public void onClick(View v) {
            int l_int=Integer.parseInt(lblNumber.getText().toString());
            if(l_int==0)
                lblNumber.setText("2");
            else
                lblNumber.setText(lblNumber.getText().toString()+"2");

        }
    };
    View.OnClickListener btn3_Click=new View.OnClickListener(){
        public void onClick(View arg0) {

            int l_int=Integer.parseInt(lblNumber.getText().toString());
            if(l_int==0)
                lblNumber.setText("3");
            else
                lblNumber.setText(lblNumber.getText().toString()+"3");

        }
    };
    View.OnClickListener btn4_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn5_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn6_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn7_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn8_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn9_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn加_Click=new View.OnClickListener(){
        public void onClick(View arg0) {
            number1=Integer.parseInt(lblNumber.getText().toString());
            op="+";
            lblNumber.setText("0");
        }
    };
    View.OnClickListener btn減_Click=new View.OnClickListener(){
        public void onClick(View arg0) {
            number1=Integer.parseInt(lblNumber.getText().toString());
            op="-";
            lblNumber.setText("0");
        }
    };
    View.OnClickListener btn乘_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn除_Click=new View.OnClickListener(){
        public void onClick(View arg0) {


        }
    };
    View.OnClickListener btn等於_Click=new View.OnClickListener(){
        public void onClick(View arg0) {
            int number2=Integer.parseInt(lblNumber.getText().toString());

            if("+".equals(op))
                lblNumber.setText(String.valueOf(number1+ number2));
            if("-".equals(op))
                lblNumber.setText(String.valueOf(number1- number2));

        }
    };

    private void InitialComponent() {
        btn0=(Button)findViewById(R.id.btn0);
        btn0.setOnClickListener(btn0_Click);
        btn1=(Button)findViewById(R.id.btn1);
        btn1.setOnClickListener(btn1_Click);
        btn2=(Button)findViewById(R.id.btn2);
        btn2.setOnClickListener(btn2_Click);
        btn3=(Button)findViewById(R.id.btn3);
        btn3.setOnClickListener(btn3_Click);
        btn4=(Button)findViewById(R.id.btn4);
        btn4.setOnClickListener(btn4_Click);
        btn5=(Button)findViewById(R.id.btn5);
        btn5.setOnClickListener(btn5_Click);
        btn6=(Button)findViewById(R.id.btn6);
        btn6.setOnClickListener(btn6_Click);
        btn7=(Button)findViewById(R.id.btn7);
        btn7.setOnClickListener(btn7_Click);
        btn8=(Button)findViewById(R.id.btn8);
        btn8.setOnClickListener(btn8_Click);
        btn9=(Button)findViewById(R.id.btn9);
        btn9.setOnClickListener(btn9_Click);
        btn加=(Button)findViewById(R.id.btnPlus);
        btn加.setOnClickListener(btn加_Click);
        btn減=(Button)findViewById(R.id.btnMin);
        btn減.setOnClickListener(btn減_Click);
        btn乘=(Button)findViewById(R.id.btnMulti);
        btn乘.setOnClickListener(btn乘_Click);
        btn除=(Button)findViewById(R.id.btnDiv);
        btn除.setOnClickListener(btn除_Click);
        btn等於=(Button)findViewById(R.id.btnOk);
        btn等於.setOnClickListener(btn等於_Click);
        lblNumber=(TextView)findViewById(R.id.lblNumber);


    }
    Button btn0;
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    Button btn6;
    Button btn7;
    Button btn8;
    Button btn9;
    Button btn加;
    Button btn減;
    Button btn乘;
    Button btn除;
    Button btn等於;
    TextView lblNumber;
}
