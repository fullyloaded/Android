package tw.org.iii.app01;

/**
 * Created by user21 on 2015/12/15.
 */
public class CLotto {

    public String GetLottoNumber(){
        int count=0;
        int[] numbers=new int[6];
        while(count<6)
        {
            double d=(int)100*Math.random();
            int temp=(int)d;
            if(temp<50&&temp>0){
                if(NumberNotSelected(temp,numbers)) {
                    numbers[count] = temp;
                    count++;
                }
            }
        }
        for (int i=0;i<numbers.length;i++){
            for (int j=0;j<numbers.length-1;j++){

                if(numbers[j]>numbers[j+1])
                {
                    int t = numbers[j+1];
                    numbers[j+1]=numbers[j];
                    numbers[j]=t;
                }
            }
        }
        String result="";
        for(int i: numbers)
            result+=String.valueOf(i)+" ";
        return result;
    }

    private boolean NumberNotSelected(int rand, int[] numbers) {

        for(int i:numbers) {
            if(rand==i)
                return false;
        }
        return true;
    }
}
