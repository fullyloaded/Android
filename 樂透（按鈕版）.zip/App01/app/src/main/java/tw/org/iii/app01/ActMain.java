package tw.org.iii.app01;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActMain extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);

        Button btn = (Button)findViewById(R.id.btnOK);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        TextView lblHello =
                (TextView)findViewById(R.id.lblHello);

        CLotto x =new CLotto();
        lblHello.setText(x.GetLottoNumber());

    }
}





