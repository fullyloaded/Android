package tw.org.iii.membersys;

/**
 * Created by user21 on 2015/12/17.
 */
public class CDictionary {
    public static final String BK_ALL_MEMBERS="BK_ALL_MEMBERS";
    public static final String BK_SELECTED_INDEX="BK_SELECTED_INDEX";
    public static final int ACTIVITYID_ACTLIST=123;
}
