package tw.org.iii.membersys;

import java.util.ArrayList;

/**
 * Created by user21 on 2015/12/17.
 */
public class CMemberFactory {

    private ArrayList<CMember> list=new ArrayList<CMember>();
    private int position;
    private void LoadData(){
        list.add(new CMember("A001","Marco","0926334516","1234","台北市"));
        list.add(new CMember("A002","Mavies","0926332321","1111","台中市"));
        list.add(new CMember("A005","John","0926336847","iii","高雄市"));
    }
    public void MoveFirst(){
        position=0;
    }
    public void MovePrevious(){
        position--;
        if(position<0)
            position=0;
    }
    public void MoveNext(){
        position++;
        if(position>=list.size())
            position=list.size()-1;
    }
    public void MoveLast(){
        position=list.size()-1;
    }
    public void MoveTo(int p){
        position=p;
    }
    public CMember GetCurrent(){
        return list.get(position);
    }
    public CMember[] GetAll(){
        return list.toArray(new CMember[list.size()]);
    }
    public CMemberFactory(){
        LoadData();
    }

}
























