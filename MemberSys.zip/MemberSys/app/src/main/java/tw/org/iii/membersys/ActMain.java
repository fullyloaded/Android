package tw.org.iii.membersys;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActMain extends AppCompatActivity {
    CMemberFactory factory = new CMemberFactory();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);
        InitialComponent();
    }
    View.OnClickListener btnFirst_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            factory.MoveFirst();
            DisplayMemberInfo();
        }
    };

    private void DisplayMemberInfo() {
        txtAccount.setText(factory.GetCurrent().getAccount());
        txtName.setText(factory.GetCurrent().getName());
        txtPhone.setText(factory.GetCurrent().getPhone());
        txtPassword.setText(factory.GetCurrent().getPassword());
        txtAddess.setText(factory.GetCurrent().getAddress());
    }

    View.OnClickListener btnPrevious_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            factory.MovePrevious();
            DisplayMemberInfo();
        }
    };
    View.OnClickListener btnNext_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            factory.MoveNext();
            DisplayMemberInfo();
        }
    };
    View.OnClickListener btnLast_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            factory.MoveLast();
            DisplayMemberInfo();
        }
    };
    View.OnClickListener btnList_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            CMember[] datas = factory.GetAll();
            String[] items=new String[datas.length];
            int count=0;
            for(CMember m : datas){
                items[count]=m.getName()+"\r\n"+
                        m.getPhone()+"/"+m.getAddress();
                count++;
            }

            Bundle bund = new Bundle();
            bund.putStringArray(CDictionary.BK_ALL_MEMBERS,items);

            Intent intent = new Intent(ActMain.this,ActList.class);
            intent.putExtras(bund);
            startActivityForResult(intent, CDictionary.ACTIVITYID_ACTLIST);

        }
    };

    @Override
    public void onActivityResult(int request,int resultCode, Intent data) {
        if(request==CDictionary.ACTIVITYID_ACTLIST){
            if(data==null)
                return;
            if(data.getExtras()==null)
                return;
            int index=data.getExtras().getInt(CDictionary.BK_SELECTED_INDEX);
            factory.MoveTo(index);
            DisplayMemberInfo();
        }
    }

    View.OnClickListener btnSearch_click = new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            factory.MoveFirst();
            for(CMember m : factory.GetAll()){
                if(m.getName().toUpperCase().contains(txtName.getText().toString().toUpperCase())) {
                    DisplayMemberInfo();
                    break;
                }
                factory.MoveNext();
            }


        }
    };
    private void InitialComponent() {
        txtAccount=(EditText)findViewById(R.id.txtId);
        txtName=(EditText)findViewById(R.id.txtName);
        txtPhone=(EditText)findViewById(R.id.txtPhone);
        txtPassword=(EditText)findViewById(R.id.txtPassword);
        txtAddess=(EditText)findViewById(R.id.txtAddress);
        btnFirst=(Button)findViewById(R.id.btnFirst);
        btnFirst.setOnClickListener(btnFirst_click);
        btnPrevious=(Button)findViewById(R.id.btnPrevious);
        btnPrevious.setOnClickListener(btnPrevious_click);
        btnNext=(Button)findViewById(R.id.btnNext);
        btnNext.setOnClickListener(btnNext_click);
        btnLast=(Button)findViewById(R.id.btnLast);
        btnLast.setOnClickListener(btnLast_click);
        btnList=(Button)findViewById(R.id.btnList);
        btnList.setOnClickListener(btnList_click);
        btnSearch=(Button)findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(btnSearch_click);

    }
    EditText txtAccount;
    EditText txtName;
    EditText txtPhone;
    EditText txtPassword;
    EditText txtAddess;
    Button btnFirst;
    Button btnPrevious;
    Button btnNext;
    Button btnLast;
    Button btnList;
    Button btnSearch;
}
